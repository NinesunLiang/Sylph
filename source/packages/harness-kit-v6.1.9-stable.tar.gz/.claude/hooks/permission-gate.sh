#!/usr/bin/env bash
# permission-gate.sh — PreToolUse:Bash — 执行危险命令前检查权限申请格式
# Role: 执行危险命令前检查权限申请格式

source "$(dirname "$0")/harness_config.sh"
hc_enabled "permission_gate" || { echo '{"continue": true}'; exit 0; }
INPUT=$(cat)

# 提取 command 字段
if command -v jq &>/dev/null; then
    COMMAND=$(echo "$INPUT" | jq -r '.tool_input.command // empty' 2>/dev/null)
else
    COMMAND=$(echo "$INPUT" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    print(data.get('tool_input', {}).get('command', ''))
except:
    pass" 2>/dev/null)
fi

[ -z "$COMMAND" ] && { echo '{"continue": true}'; exit 0; }

# 从 harness.yaml 读取 regex 模式（fallback 为内置默认值）
GIT_COMMIT_RE=$(hc_get "permission_gate.git_commit_regex" 'git\s+(commit|add\s+--?all|\badd\b.*-A)')
GIT_PUSH_FORCE_RE=$(hc_get "permission_gate.git_push_force_regex" 'git\s+push\s+(\S+\s+)?(\S+\s+)?--?force|git\s+push\s+--?force')
GIT_PUSH_RE=$(hc_get "permission_gate.git_push_regex" 'git\s+push\b')
DESTRUCTIVE_RE=$(hc_get "permission_gate.destructive_regex" '\brm\s+-rf\b|\bdrop\s+(table|database|collection|schema)\b|\btruncate(\s+table)?\s+\S|\bdelete\s+from\b')
SUDO_RE=$(hc_get "permission_gate.sudo_regex" '^\s*sudo\b|sudo\s')
GH_WRITE_RE=$(hc_get "permission_gate.gh_write_regex" 'gh\s+(release\s+(upload|create|edit|delete)|pr\s+(create|merge|close|review\s+--approve)|issue\s+(create|close|comment)|repo\s+(create|delete|rename)|variable\s+set|secret\s+set|workflow\s+(run|disable|enable)|api\s+.*-X\s+(PUT|POST|PATCH|DELETE))\b')
SCOPE_WRITE_RE=$(hc_get "permission_gate.scope_write_regex" 'current-scope\.txt')

# 危险命令检测
IS_DANGEROUS=false
DANGER_TYPE=""

# git commit 检测
if echo "$COMMAND" | grep -qE "$GIT_COMMIT_RE"; then
    # 排除只读操作
    if echo "$COMMAND" | grep -qvE 'git\s+commit\s+--dry-run|git\s+commit\s+--help'; then
        IS_DANGEROUS=true
        DANGER_TYPE="git commit"
    fi
fi

# git push 检测
if echo "$COMMAND" | grep -qE "$GIT_PUSH_FORCE_RE"; then
    IS_DANGEROUS=true
    DANGER_TYPE="git push --force"
elif echo "$COMMAND" | grep -qE "$GIT_PUSH_RE" && ! echo "$COMMAND" | grep -qE 'git\s+push\s+--?dry-run|git\s+push\s+--help'; then
    IS_DANGEROUS=true
    DANGER_TYPE="git push"
fi

# 删除操作检测（-i 忽略大小写，覆盖 DROP TABLE / TRUNCATE 等 SQL 大写形式）
if echo "$COMMAND" | grep -iqE "$DESTRUCTIVE_RE"; then
    IS_DANGEROUS=true
    DANGER_TYPE="destructive operation"
fi

# sudo 检测
if echo "$COMMAND" | grep -qE "$SUDO_RE"; then
    IS_DANGEROUS=true
    DANGER_TYPE="sudo"
fi

# gh 写操作检测（release upload/create, pr create/merge, issue create/close, secret set 等）
if echo "$COMMAND" | grep -qE "$GH_WRITE_RE"; then
    IS_DANGEROUS=true
    DANGER_TYPE="gh external write"
fi

# scope 文件写入检测（防止 AI 自绕过 scope gate）
# 注意：排除只读操作（ls/cat/echo 无重定向/python 读/变量赋值等）
if echo "$COMMAND" | grep -qE "$SCOPE_WRITE_RE"; then
    # 使用 ! grep -qE（而非 grep -qvE）支持多行命令正确匹配
    if ! echo "$COMMAND" | grep -qE '^\s*ls\b|^\s*cat\b|echo\s+"[^">]*"$|echo\s+'\''[^'\'']*'\''$|echo\s+['\''"][^'\''"]+['\''"]\s*>>|python3\s+-c\s|^\s*source\b|^\s*\.\s|grep\b|wc\b|head\b|tail\b|^f=|^d=|^fn=|^a='; then
        IS_DANGEROUS=true
        DANGER_TYPE="scope gate bypass"
    fi
fi

# 非危险命令 → 放行
[ "$IS_DANGEROUS" = false ] && { echo '{"continue": true}'; exit 0; }

# 危险命令已确认 → 先解析路径（无人值守 + 验证码共用）
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
STATE_DIR="$PROJECT_ROOT/.omc/state"

# ─── 统一模式检测 + 缓存 ──────────────────────────
# ghost/unattended 模式: 记录 flywheel + skipped-errors，不 exit 2
# approved-ops 缓存: 5 分钟内相同签名自动放行（UX-2.3）
MODE=$(is_mode_active "$STATE_DIR")
CACHE_FILE="$STATE_DIR/approved-ops.json"

# 检查缓存：相同命令签名在 5 分钟内是否已批准
check_cache() {
    local cmd_sig="$1"
    if [ ! -f "$CACHE_FILE" ]; then
        return 1
    fi
    python3 -c "
import json, time, sys
try:
    d = json.load(open('$CACHE_FILE'))
    sig = '$cmd_sig'
    entry = d.get(sig)
    if entry and time.time() - entry.get('ts', 0) < 300:
        print('hit')
    else:
        print('miss')
except:
    print('miss')
" 2>/dev/null | grep -q 'hit'
}

write_cache() {
    local cmd_sig="$1"
    local ts
    ts=$(python3 -c "import time; print(int(time.time()))" 2>/dev/null)
    python3 -c "
import json, os
try:
    d = json.load(open('$CACHE_FILE'))
except:
    d = {}
d['$cmd_sig'] = {'ts': $ts, 'type': '$DANGER_TYPE'}
tmp = '$CACHE_FILE.tmp.$$'
with open(tmp, 'w') as f:
    json.dump(d, f)
os.rename(tmp, '$CACHE_FILE')
" 2>/dev/null
}

# 统一模式检测: ghost/unattended 降级为"记录+跳过"，不阻断
if [ "$MODE" != "normal" ]; then
    echo "$(date +%Y-%m-%d),permission_gate_blocked_${DANGER_TYPE// /_},P0,carror-os" >> "$HOME/.claude/flywheel.log"
    SKIPPED_FILE="$STATE_DIR/skipped-errors.md"
    {
        echo ""
        echo "## $(date '+%Y-%m-%d %H:%M:%S') — permission-gate ${MODE} mode [${DANGER_TYPE}]"
        echo '```'
        echo "$COMMAND"
        echo '```'
    } >> "$SKIPPED_FILE"
    echo "[${MODE}] 已记录 ${DANGER_TYPE}: ${COMMAND:0:120}...（模式降级，不阻断）" >&2
    echo '{"continue": true}'
    exit 0
fi

# 检查缓存：5 分钟内已批准的同签名操作 → 自动放行
CMD_SIG=$(echo "$COMMAND" | head -c 120)
if check_cache "$CMD_SIG"; then
    echo "[权限缓存] 5 分钟内已批准的同签名操作: ${COMMAND:0:80}..." >&2
    echo '{"continue": true}'
    exit 0
fi

# ─── 随机验证码审批机制 ──────────────────────────
# 原理：Hook 生成随机 hex 码写入 state，阻断时仅在用户终端打印该码。
# AI 无法预知验证码，只有用户手动 echo 验证码到标记文件才能放行。
# 这从根本上解决了旧版「AI 自写标记文件绕过审批」的问题。
PERMISSION_MARKER="$STATE_DIR/permission-approved"
PERMISSION_REQUIRED="$STATE_DIR/permission-required"

# 检查是否有待处理的验证码（即有未完成的审批流程）
if [ -f "$PERMISSION_REQUIRED" ]; then
    EXPECTED_CODE=$(cat "$PERMISSION_REQUIRED" 2>/dev/null)
    if [ -f "$PERMISSION_MARKER" ]; then
        ACTUAL_CODE=$(cat "$PERMISSION_MARKER" 2>/dev/null)
        # 检查标记文件新鲜度（5分钟内有效）
        if [ "$ACTUAL_CODE" = "$EXPECTED_CODE" ]; then
            if command -v python3 &>/dev/null; then
                FRESH=$(python3 -c "import os, time
try:
    age = time.time() - os.path.getmtime('$PERMISSION_MARKER')
    print('yes' if age < 300 else 'no')
except:
    print('no')" 2>/dev/null)
            else
                FRESH="yes"
            fi
            if [ "$FRESH" = "yes" ]; then
                # 验证码匹配 → 有效授权，清理并放行 + 写入缓存
                CMD_SIG=$(echo "$COMMAND" | head -c 120)
                write_cache "$CMD_SIG"
                rm -f "$PERMISSION_MARKER" "$PERMISSION_REQUIRED"
                echo '{"continue": true}'
                exit 0
            fi
        fi
    fi
    # 标记文件过期或验证码不匹配 → 清理旧码，重新生成
    rm -f "$PERMISSION_REQUIRED"
fi

# 阻断：无有效权限申请 → 生成随机验证码，写入 state 文件
case "$DANGER_TYPE" in
    "git push --force")
        SEVERITY="🔴 致命" ;;
    "destructive operation")
        SEVERITY="🔴 致命" ;;
    *)
        SEVERITY="🟡 高危" ;;
esac

# 生成随机 8 位 hex 验证码（AI 无法预知，只在用户终端显示）
APPROVAL_CODE=$(python3 -c "import secrets; print(secrets.token_hex(4))" 2>/dev/null || echo "perm-$$-$(date +%s)")
echo "$APPROVAL_CODE" > "$PERMISSION_REQUIRED"

PERMISSION_FILE="${PROJECT_ROOT}/.omc/state/permission-approved"
echo "Permission Gate: ${SEVERITY} 级别操作 — ${DANGER_TYPE}" >&2
echo '复制这一行并粘贴到输入框（含 ! 前缀）：' >&2
echo "! echo '${APPROVAL_CODE}' > ${PERMISSION_FILE}" >&2
exit 2
