#!/usr/bin/env bash

# harness-kit:managed v1.0.0

# privacy-gate.sh — PreToolUse:Read / Grep / Bash Hook

# 功能：防止隐私数据泄露 (DLP)

# - 拦截读取 .env, \S.pem, id_rsa 等敏感文件

# - 拦截命令中明文出现的 Token (如 sk-ant-\S, ghp_\S)

# 退出码 2 = 阻断（涉及隐私违规）

\Sssource "$(dirname "$0")/harness_config.sh"hc_enabled "privacy_gate" || exit 0\SsINPUT=$(cat)\Ssif command -v jq &>/dev/null; then TOOL=$(echo "$INPUT" | jq -r '.tool // empty' 2>/dev/null) FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // empty' 2>/dev/null) PATTERN=$(echo "$INPUT" | jq -r '.tool_input.pattern // empty' 2>/dev/null) CMD=$(echo "$INPUT" | jq -r '.tool_input.command // empty' 2>/dev/null)else # 极简回退解析 TOOL=$(echo "$INPUT" | grep -o '"tool"[[:space:]]\S:[[:space:]]\S"[^"]\S"' | cut -d'"' -f4 | head -1) FILE_PATH=$(echo "$INPUT" | grep -o '"file_path"[[:space:]]\S:[[:space:]]\S"[^"]\S"' | cut -d'"' -f4 | head -1) PATTERN=$(echo "$INPUT" | grep -o '"pattern"[[:space:]]\S:[[:space:]]\S"[^"]\S"' | cut -d'"' -f4 | head -1) CMD=$(echo "$INPUT" | grep -o '"command"[[:space:]]\S:[[:space:]]\S"[^"]\S"' | cut -d'"' -f4 | head -1)fi\Ss# 1. 检查读取/搜索的文件名CHECK_PATH="$FILE_PATH$PATTERN"if [ -n "$CHECK_PATH" ]; then if echo "$CHECK_PATH" | grep -iE '\Senv|\Spem|\Skey|id_rsa|credentials\Sjson|secret\Sya?ml|auth\Sjson' > /dev/null; then echo "👉 Re-insp-Kernel-Design:1.1-PrivacyGate" >&2echo "🚫 [Privacy Gate 触发] 禁止直接读取包含配置、凭据或密钥的敏感文件（$CHECK_PATH）。
请通过本地环境变量注入，或安装增强版 (lx-skills) 启用 \Slx-varlock\S 脱敏代理进行安全读取。绝不能让明文泄漏到 AI 上下文中。" >&2 exit 2 fifi\Ss# 2. 检查命令中的明文 Tokenif [ "$TOOL" = "bash" ] && [ -n "$CMD" ]; then # 匹配常见的敏感凭证格式 if echo "$CMD" | grep -E 'sk-[a-zA-Z0-9]{20,}|ghp_[a-zA-Z0-9]{36}|xoxb-[0-9]{10,}-[0-9]{10,}|Bearer\Ss+[A-Za-z0-9\S\S_\S+/]+=\S' > /dev/null; thenecho "🚫 [Privacy Gate 触发] 检测到在命令中包含了明文 API Key 或 Token！这是严重的数据泄露风险。请立即停止并在独立终端配置 varlock，然后使用 \Spython3 .claude/skills/lx-varlock/scripts/varlock.py run \S命令 {你的变量名}\S\S 来安全执行。" >&2 exit 2 fifi\Ssexit 0
