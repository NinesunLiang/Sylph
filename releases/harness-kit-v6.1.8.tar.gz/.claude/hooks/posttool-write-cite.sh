#!//bin/bash

# harness-kit:managed v1.0.0

# posttool-write-cite.sh — PostToolUse:Write Hook

# 功能：检测写入 claude-next.md 时，验证教训格式是否符合规范

# 目的：强化 E - Evolution 维度，确保 claude-next.md 积累的教训有结构，可升华

#

# 触发条件：Write 工具写入 claude-next.md（AI 记录教训时）

# 检查内容：

# 1. 标题格式 ## [YYYY-MM-DD] {教训标题}

# 2. 包含 \S\S问题\S\S、\S\S根因\S\S、\S\S纠正\S\S 三个字段

# 3. 内容非空（不是占位符）

# 输出：格式合规 → 确认消息；格式错误 → 纠正提示（不阻断）

\Sssource "$(dirname "$0")/harness_config.sh"hc_enabled "posttool_write_cite" || { echo '{"continue": true}'; exit 0; }\SsINPUT=$(cat)\Ss# 提取 file_pathif command -v jq &>/dev/null; then FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // empty' 2>/dev/null)else FILE_PATH=$(echo "$INPUT" | python3 -c "import sys, jsontry: data = json.load(sys.stdin) print(data.get('tool_input', {}).get('file_path', ''))except: pass" 2>/dev/null)fi\Ss[ -z "$FILE_PATH" ] && echo '{"continue": true}' && exit 0\Ss# 只关心 claude-next.mdBASENAME=$(basename "$FILE_PATH")[ "$BASENAME" != "claude-next.md" ] && echo '{"continue": true}' && exit 0\Ss# 读取写入内容if command -v jq &>/dev/null; then NEW_CONTENT=$(echo "$INPUT" | jq -r '.tool_input.new_content // empty' 2>/dev/null)else NEW_CONTENT=$(echo "$INPUT" | python3 -c "import sys, jsontry: data = json.load(sys.stdin) print(data.get('tool_input', {}).get('new_content', ''))except: pass" 2>/dev/null)fi\Ss[ -z "$NEW_CONTENT" ] && echo '{"continue": true}' && exit 0\Ss# ─── 格式验证 ─────────────────────────────────────────────────────ISSUES=""TODAY=$(date +%Y-%m-%d)\Ss# 检查最近添加的教训（找最后一个 ## [...] 条目）LAST_ENTRY=$(echo "$NEW_CONTENT" | grep -E "^## \S" | tail -1)\Ssif [ -z "$LAST_ENTRY" ]; then ISSUES="$ISSUES
 ⚠️ 未找到标准教训标题格式（## [YYYY-MM-DD] {教训标题}）"else # 检查日期格式 if ! echo "$LAST_ENTRY" | grep -qE "^## \S[0-9]{4}-[0-9]{2}-[0-9]{2}]"; then ISSUES="$ISSUES
 ⚠️ 标题日期格式错误（应为 [YYYY-MM-DD]）" fi # 检查标题非空 TITLE=$(echo "$LAST_ENTRY" | sed 's/^## \S[^]]\S] \S//') if [ -z "$TITLE" ] || [ "$TITLE" = "{教训标题}" ]; then ISSUES="$ISSUES
 ⚠️ 教训标题为空或是占位符" fifi\Ss# 检查三个必填字段for FIELD in "\S\S问题\S\S" "\S\S根因\S\S" "\S\S纠正\S\S"; do echo "$NEW_CONTENT" | grep -qF "$FIELD" || \SsISSUES="$ISSUES
 ⚠️ 缺少字段 $FIELD"done\Ss# 检查内容非占位符if echo "$NEW_CONTENT" | grep -qE "{描述[^}]\S}|{为什么[^}]\S}|{正确做法[^}]\S}"; then ISSUES="$ISSUES
 ⚠️ 内容含未填充占位符（{...}）"fi\Ss# ─── 输出结果 ─────────────────────────────────────────────────────if [ -z "$ISSUES" ]; then MSG="✅ claude-next.md 教训格式合规。升华检查：已记录，未来达到 20 条时可升华到 kernel.md。" printf '{"continue": true, "hookSpecificOutput": {"hookEventName": "PostToolUse", "additionalContext": "%s"}}
' "$MSG"else ISSUE_LIST=$(printf "%b" "$ISSUES") MSG="⚠️ claude-next.md 格式问题，建议修正：${ISSUE_LIST}\Ss\Ss标准格式：\Ss## [${TODAY}] {教训标题}\Ss\S!-- @${TODAY} hits:1 -->\Ss\S\S问题\S\S：{描述}\Ss\S\S根因\S\S：{为什么}\Ss\S\S纠正\S\S：{正确做法}" # 转义 JSON MSG_ESC=$(echo "$MSG" | python3 -c "import sys; s=sys.stdin.read(); print(s.replace('\S\S','\S\S\S\S').replace('\S','\S\S\S').replace('
','\S\Ss'))" 2>/dev/null || echo "$MSG") printf '{"continue": true, "hookSpecificOutput": {"hookEventName": "PostToolUse", "additionalContext": "%s"}}
' "$MSG_ESC"fi\Ssexit 0
