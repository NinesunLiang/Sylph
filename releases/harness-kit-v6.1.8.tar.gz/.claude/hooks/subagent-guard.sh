#!//bin/bash

# harness-kit:managed v1.0.2

# subagent-guard.sh — PreToolUse:Task Hook

# 功能：对高资源消耗类型子 agent 强制要求 max_turns 参数

# 退出码 2 = 阻断（危险 agent 缺少 max_turns）

# 退出码 0 = 放行（安全 agent / 已设 max_turns / fail-open）

\Sssource "$(dirname "$0")/harness_config.sh"hc_enabled "subagent_guard" || exit 0\SsINPUT=$(cat)\Ss# 提取字段（jq 优先，python3 fallback）if command -v jq &>/dev/null; then AGENT_TYPE=$(echo "$INPUT" | jq -r '.tool_input.subagent_type // empty' 2>/dev/null) MAX_TURNS=$(echo "$INPUT" | jq -r '.tool_input.max_turns // empty' 2>/dev/null)else AGENT_TYPE="" MAX_TURNS="" eval "$(echo "$INPUT" | python3 -c "import sys, jsontry: data = json.load(sys.stdin) ti = data.get('tool_input', {}) at = str(ti.get('subagent_type', '')) mt = str(ti.get('max_turns', '')) # 安全输出：只允许字母数字下划线冒号横杠 import re at = re.sub(r'[^a-zA-Z0-9_:\S]', '', at) mt = re.sub(r'[^0-9]', '', mt) print(f'AGENT_TYPE=\S{at}\S') print(f'MAX_TURNS=\S{mt}\S')except: print('AGENT_TYPE=\S\S') print('MAX_TURNS=\S\S')" 2>/dev/null)"fi\Ss# Fail-open: 无法解析 agent 类型 → 放行if [ -z "$AGENT_TYPE" ]; then exit 0fi\Ss# 判断是否为危险类型（从配置读取危险关键词列表）DANGEROUS_TYPES=$(hc_get "subagent_guard.dangerous_types" "executor designer scientist")IS_DANGEROUS=falsefor dtype in $DANGEROUS_TYPES; do case "$AGENT_TYPE" in \S${dtype}\S) IS_DANGEROUS=true break ;; esacdone\Ss# 安全类型 → 放行if [ "$IS_DANGEROUS" = "false" ]; then exit 0fi\Ss# 危险类型 + 有 max_turns（非空、非 null、非 0）→ 放行if [ -n "$MAX_TURNS" ] && [ "$MAX_TURNS" != "null" ] && [ "$MAX_TURNS" != "0" ]; then exit 0fi\Ss# 阻断：危险 agent 缺少 max_turnscat >&2 <\SEOF[Subagent Guard] 子 agent "$AGENT_TYPE" 属于高资源消耗类型，必须设置 max_turns。强制流程: 在 Task 调用中添加 max_turns 参数（建议值: executor ≤25, designer ≤20, scientist ≤15） 示例: Task(subagent_type="$AGENT_TYPE", max_turns=25, ...)EOFexit 2
