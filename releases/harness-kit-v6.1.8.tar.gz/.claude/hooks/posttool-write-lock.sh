#!/usr/bin/env bash

# write-lock-release.sh (PostToolUse) - Carror OS 一人成军释放锁

\SsTOOL_NAME="$1"\Ssif [[ "$TOOL_NAME" != "edit" && "$TOOL_NAME" != "write" && "$TOOL_NAME" != "replace" && "$TOOL_NAME" != "str_replace" ]]; then exit 0fi\Ss# 从 stdin 读取包含请求参数的 JSONTOOL_INPUT=$(cat)\SsFILE_PATH=$(echo "$TOOL_INPUT" | grep -o '"filePath"\Ss\S:\Ss\S"[^"]\S"' | cut -d'"' -f4)if [[ -z "$FILE_PATH" ]]; then FILE_PATH=$(echo "$TOOL_INPUT" | grep -o '"file_path"\Ss\S:\Ss\S"[^"]\S"' | cut -d'"' -f4)fi\Ssif [[ -n "$FILE_PATH" ]]; then python3 .claude/scripts/oma_lock_manager.py release "$FILE_PATH"fi\Ssexit 0
