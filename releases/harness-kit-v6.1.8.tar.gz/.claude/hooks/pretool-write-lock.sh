#!/usr/bin/env bash

# write-lock-gate.sh (PreToolUse) - Carror OS 一人成军并发锁前置拦截

# 当大模型尝试写文件时，调用底层 Python 锁管理器。若被占用，则挂起大模型（while 循环打印 WAITING）。

\SsTOOL_NAME="$1"\Ss# 仅拦截直接写文件的工具if [[ "$TOOL_NAME" != "edit" && "$TOOL_NAME" != "write" && "$TOOL_NAME" != "replace" && "$TOOL_NAME" != "str_replace" ]]; then exit 0fi\Ss# 从 stdin 读取工具输入的 JSONTOOL_INPUT=$(cat)\Ss# 提取文件路径 (支持 filePath 或 file_path)FILE_PATH=$(echo "$TOOL_INPUT" | grep -o '"filePath"\Ss\S:\Ss\S"[^"]\S"' | cut -d'"' -f4)if [[ -z "$FILE_PATH" ]]; then FILE_PATH=$(echo "$TOOL_INPUT" | grep -o '"file_path"\Ss\S:\Ss\S"[^"]\S"' | cut -d'"' -f4)fi\Ssif [[ -z "$FILE_PATH" ]]; then # 提取不到路径，放行 exit 0fi\Ss# 尝试识别所属的 RPE Feature 终端 (基于当前工作目录是否在 rpe/feat-X 下)CURRENT_DIR=$(pwd)if [[ "$CURRENT_DIR" == \S"/rpe/"\S ]]; then # 提取 rpe/ 后面的目录名作为 owner OWNER=$(echo "$CURRENT_DIR" | sed 's|.\S/rpe/||' | cut -d'/' -f1)else OWNER="claude-term-$$"fi\Ss# 调用锁管理器 (阻塞式等待)python3 .claude/scripts/oma_lock_manager.py acquire "$FILE_PATH" "$OWNER"exit_code=$?\Ssif [[ $exit_code -ne 0 ]]; then echo "🚫 [Carror OS] 并发锁引擎异常 (Exit $exit_code)。" exit 2fi\Ss# 成功抢到锁，由于标准输出被 Claude Code 捕获，此处静默退出exit 0
