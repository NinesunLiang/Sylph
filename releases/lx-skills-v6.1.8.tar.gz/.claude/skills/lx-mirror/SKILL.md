
---

name: lx-mirror

description: Mirror（镜子）— 屎山重构指导系统。生成地图，不做实施。做少量正确高价值的事（指导），不做大量不可能有结果的妄想。

version: 1.0.0


---

# lx-mirror — Mirror（镜子）重构指导系统

**触发语**：`/lx-mirror`、`镜像分析`、`屎山指导`

---

## 核心原则

> **Mirror 是地图，不是挖掘机。它做指导，不做实施。**

Mirror 的每一个指令，产出的都是 **Markdown 指导文档**（存放在 `.omc/mirror/`），不生成任何业务代码。

---

## 指令路由

收到 `/lx-mirror` 时，解析第一个参数作为子命令：
```/lx-mirror scan \<path> → 扫描项目，生成现实地图/lx-mirror genesis → 访谈架构师，生成理想架构蓝图/lx-mirror dag → 生成节点依赖图 + 上帝节点清单/lx-mirror plan → 拓扑排序迁移计划/lx-mirror guide \<node
> → 为单个节点生成重写指导卡/lx-mirror risks → 生成风险登记表```
未提供子命令时，打印帮助并询问用户要执行哪个步骤。

---

## 子命令实现规范

### `scan \<project_path>`

**调用 Python 脚本执行确定性扫描**（固定逻辑，不依赖 AI 生成）：
```bashpython3 .claude/skills/lx-mirror/scripts/mirror_scan.py \<project_path>```
脚本自动生成：- `.omc/mirror/reality-map.md`（项目现实扫描报告）- `.omc/mirror/nodes/\<func_name>/schema.md`（每个函数的 I/O Schema 桩）- `.omc/mirror/.scan-meta.json`（供后续子命令读取的元数据）
执行完毕后，向用户展示摘要：函数总数、上帝节点、异味节点。建议用户下一步执行 `/lx-mirror genesis`。

---

### `genesis`

**结构化访谈模式**。以引导式问答的方式，让架构师定义"完美世界"。
按以下顺序逐一提问（每个问题等待用户回答后再继续）：
1. **目录结构**："请描述理想的项目目录结构（按功能/领域/层次划分）。"2. **调用范式**："模块间调用有哪些禁止路径？（例如：handler 层禁止直接调用 DB）"3. **数据流向**："数据在系统中应如何单向流动？描述主干流向。"4. **代码法律**："有哪些全局强制规则？（例如：禁止全局变量、函数不超过 50 行）"5. **深度规范**："函数调用层级最多几层？命名规范是什么？"
收集完所有答案后，生成 `.omc/mirror/genesis.md`，格式如下：
```markdown# 理想架构蓝图（Genesis）

## 目录结构规范（用户的回答，整理为标准 tree 结构）

## 模块调用规范（允许路径 / 禁止路径，以 ✅/❌ 标注）

## 数据流向规范（单向流程图，Mermaid 格式）

## 代码法律（全局强制，违反即 Block Review）1. ...2. ...

## 函数深度与命名规范...```

> ⚠️ 关键提示：Genesis 生成后，必须向用户明确说明：
> "Genesis 是整个 Mirror 的地基。请认真检查每一项规范，确认无误后再继续。任何 Genesis 层面的错误都会传导到所有后续步骤。"

---

### `dag`

读取 `.omc/mirror/.scan-meta.json` 和 `.omc/mirror/reality-map.md`。
根据已扫描的函数调用关系，生成 `.omc/mirror/dag.md`，包含：
1. **有向依赖图（Mermaid flowchart）**2. **上帝节点清单**（红色标注，附隔离区说明）3. **循环依赖列表**（如果存在）4. **叶子节点清单**（无下游依赖，最先迁移的候选）
格式：```markdown# 节点依赖图（DAG）

## 依赖关系图

（Mermaid flowchart，节点间单向箭头）

## 上帝节点（⚠️ 隔离区，最后处理）

- 🔴 `OrderCore`：被 23 个节点引用...

## 叶子节点（✅ 优先迁移）

- `PriceCalculator`：无下游依赖，纯计算函数

## 循环依赖（需 DIP 拆解）

- `ServiceA` ↔ `ServiceB`：建议提取公共接口...```

---

### `plan`

读取 `.omc/mirror/dag.md` 和 `.omc/mirror/genesis.md`。
生成 `.omc/mirror/migration-plan.md`，以拓扑顺序列出所有节点的迁移顺序：
```markdown# 迁移顺序计划

## 阶段一：叶子节点（风险低，优先迁移）- [ ] `PriceCalculator` 风险：🟢 低 预估工时：2h - 无前置依赖

- [ ] `UserProfileMapper` 风险：🟢 低 预估工时：1h

## 阶段二：中间节点（等阶段一完成）- [ ] `OrderService` 风险：🟡 中 预估工时：1天 

- 前置：PriceCalculator ✓ / UserProfileMapper ✓

## 阶段三：上帝节点（最后，独立灰度窗口 ≥5天）- [ ] `god-node-OrderCore` 风险：🔴 极高 预估工时：1周+ - ⚠️ 必须等所有中间节点完成后处理 

- ⚠️ 建议单独设立灰度压测窗口```

---

### `guide \<node_name>`

读取 `.omc/mirror/nodes/\<node_name>/schema.md` 和 `.omc/mirror/genesis.md`。
生成 `.omc/mirror/nodes/\<node_name>/rewrite-guide.md`，格式：
```markdown# 重写指导卡：`\<node_name>`

## 当前状态（屎山侧）

- 所在文件：...

- 当前行数：...
- 当前职责：...（如有复合动作，明确列出）

## 目标状态（镜像侧，符合 Genesis 规范）- 拆分为 N 个职责单一函数： 

- `funcA(input) -> output`：负责...

- `funcB(input) -> output`：负责...

## 迁移前置条件

- 依赖节点（必须先完成）：...

## 风险提示（从九大威胁中筛选适用项）

- （只列出与本节点相关的威胁）

## 验收标准- [ ] 编译通过- [ ] 影子测试输出一致率 ≥ 99.9%（连续 ≥ 1 万次请求）- [ ] 人类确认业务语义等价

- [ ] 适配器层（如需）已就绪```

> 注意：rewrite-guide.md 是**工程师的行动指南**，不是代码实现。
> 语言要简洁、可操作，避免模糊描述。

---

### `risks`

综合 `.omc/mirror/reality-map.md` + `.omc/mirror/dag.md`，生成 `.omc/mirror/risk-register.md`：
```markdown# 风险登记表（Risk Register）

## 全局威胁一览

| # | 威胁 | 严重程度 | 受影响节点 | 预防措施 |
|:--|:----|:--------|:----------|:--------|
| 1 | AI 创世幻觉 | 🔴 极高 | 全部 | Genesis 人类审批 |
| 2 | 上帝节点困局 | 🔴 极高 | OrderCore | 拓扑排序最后处理 |...

## 节点级风险登记

### `OrderService`- ⚠️ 令牌腐烂：回放时需 Token Stub

- ⚠️ 库存副作用：需影子 DB```

---

## 交付完成后的统一提示

每个子命令执行完毕，必须输出：
```✅ 已生成：.omc/mirror/\<output_file>
📌 下一步建议： → 阅读并审阅本文件，确认无误 → 执行 /lx-mirror \<next_subcommand>
⚠️ 提醒：Mirror 提供地图，不做实施。 所有重写工作由工程师参考指导卡后手动执行。```

---

## 降级策略

如果 Python 环境不可用（`scan` 子命令依赖 Python）：
```🚫 [Mirror] 致命错误：未检测到 Python 3.8+ 环境。scan 子命令依赖 Python 进行 AST 分析。请安装 Python 3.8+ 并确保加入 PATH，然后重试。
其他子命令（genesis / dag / plan / guide / risks）不依赖 Python，可正常使用。```
