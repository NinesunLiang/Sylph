#!/usr/bin/env python3

"""

extract_ac.py — 从 plan.md 提取指定 Task 的 AC 列表

用法：python3 extract_ac.py --feature \Sname> --task \SRPE-xxx>

输出：JSON AC 列表

"""

import argparse, sys, json, re

from pathlib import Path

\Ssdef main(): p = argparse.ArgumentParser() p.add_argument("--feature", required=True) p.add_argument("--task", required=True) args = p.parse_args()\Ss&#x20;plan_file = Path(f"rpe/{args.feature}/plan.md") if not plan_file.exists(): print(json.dumps({"status": "error", "error": f"plan.md not found: {plan_file}"})) sys.exit(2)\Ss&#x20;content = plan_file.read_text(encoding="utf-8")\Ss&#x20;# 找到 Task 区块（RPE-xxx 开始到下一个 RPE- 或文件结尾） pattern = rf"(?s)({re.escape(args.task)}.\S?)(?=RPE-\Sd+|\SZ)" match = re.search(pattern, content) if not match: print(json.dumps({"status": "not_found", "task": args.task})) sys.exit(0)\Ss&#x20;task_block = match.group(1)\Ss&#x20;# 提取 AC 条目（- [ ] AC-N: 描述 格式） ac_items = re.findall(r"- \S.] (AC-\Sd+[^:
]\S:[^
]+)", task_block) ac_list = [{"id": m.split(":")[0].strip(), "desc": ":".join(m.split(":")[1:]).strip()} for m in ac_items]\Ss&#x20;print(json.dumps({ "status": "success", "task": args.task, "ac_count": len(ac_list), "ac_list": ac_list }, ensure_ascii=False, indent=2))\Ssif __name__ == "__main__": main()
