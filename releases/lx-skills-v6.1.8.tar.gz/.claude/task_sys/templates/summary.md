# summary.md 模板

```markdown# Summary: {task_name}

## 任务信息

- task_name: ...

- role: ...
- priority: ...
- executor_mode: ...

## 最终状态- state: done | blocked

- 完成时间: ...

## 产出清单

- 变更文件: ...

- 新增文件: ...

## 错误模式→新规则（写入 next-learn）

- 错误：...

- 新规则：...```
