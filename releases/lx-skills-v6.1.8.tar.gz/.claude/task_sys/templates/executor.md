# executor.md 模板

```markdown# Executor: {task_name}

## 当前状态

- state: executing | blocked | done

## 本轮产出

### 方案/变更1. ...

### 证据

- [已验证: path:line] ...

- [已测试: cmd + output 摘要] ...
- [用户确认] ...

### 风险与回退

- 风险：...

- 回退：...

## 需要用户裁定

- A: ...

- B: ...

## 下一步

- [ ] ...```
