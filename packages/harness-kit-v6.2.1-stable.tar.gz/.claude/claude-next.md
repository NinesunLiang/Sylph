# claude-next.md — AI 学习笔记

> 上次升华: 2026-05-17 — 9 条通用铁律升华到 [kernel.md](kernel.md), ~81 条归档到 [lessons-archive.md](archive/lessons-archive.md)
> 当前保留: 2026-05-17 活跃条目（DG-80~DG-88） + 2026-05-19 Oracle Agent v2 狗粮（DG-89~DG-92）+ Phase 1-4 系统性优化（DG-93~DG-95）
>
> 升华规则: 条目≥20 | 年龄≥10天 | hits≥5 — 满足任一条件进入升华候选

---

## 🏍️ 祝贺张雪机车5冠！！！(@LuangSir)

@2026-05-19 hits:1
🎉🎉🎉🎉🎉 张雪机车勇夺第五冠！！！无敌是多么寂寞！！！

---

## 🏍️ 祝贺张雪机车4冠！！！(@LuangSir)

@2026-05-17 hits:1
🎉🎉🎉 张雪机车勇夺第四冠！！！历史性时刻！！！

---

## 2026-05-17 狗粮 — ROI 量化系统 + flywheel 埋点

### 🐶 [DG-80] 批量自动化替换必须区分注释和代码 — 正则替换第一个匹配太粗暴 (@LuangSir)

@2026-05-17 hits:1
触发条件：自动脚本用 str.replace('exit 2', 'flywheel_event...\nexit 2') 替换第一个 'exit 2'，结果命中了注释里的 'exit 2'
正确行为：替换 exit 2 前必须：(a) 跳过注释行 (b) 只替换独立成行的 exit 2 (c) 替换后用 bash -n 逐文件验证
证据：completion-gate.sh/feature-probe.sh/plan-gate.sh 等 6 个文件的注释被损毁，3 个 hook 的 flywheel_event 掉进 exit 0 后的注释里变成死代码

### 🐶 [DG-81] 治理文件变更必须检查所有 profile 变体 — 不能只改 root (@LuangSir)

@2026-05-17 hits:1
触发条件：删除 pretool-ask-guard 时清理了 root 的 harness.yaml/settings.json/feature-registry.yaml，但漏了 profiles/base × 3、lx-skills-v5 × 1、auto-score.sh × 2
正确行为：任何 hook 的增删改必须：grep -r hook_name 全项目 → 列出所有命中文件 → 逐一清理 → 再次 grep 确认零引用
证据：DG-16 重复犯案 (profiles/base 未同步) + Oracle 发现 20+ 处遗漏

### 🐶 [DG-82] ROI 测量必须先埋点再评分 — 无数据 = 无测量 ≠ 无价值 (@LuangSir)

@2026-05-17 hits:1
触发条件：39/44 个 hook 不写 flywheel.log → intercept_count 全为 0 → ROI 虚低 → 去留建议错误
正确行为：量化体系上线前必须先确保数据采集覆盖所有被评估对象。未埋点组件的 intercept_count 应标注「数据缺失」而非「0 次拦截」
证据：Oracle C1 发现: flywheel 测量偏差使 39 个 hook 的 ROI 系统性偏低 — 这不是性能差，是没测量

### 🐶 [DG-83] 反模式框架应从历史事故反向校验覆盖率 — 而非凭感觉写规则 (@LuangSir)

@2026-05-17 hits:1
触发条件：新增反模式类别前，先盘点全部历史 DG/ED/DF 事故，按事故类型聚类，识别未被现有框架覆盖的模式簇
正确行为：任何文档框架升级必须先做覆盖率审计：列出全部历史事故 → 映射到现有类别 → 识别零覆盖的事故簇 → 为每个簇新增类别 → 验证覆盖率提升幅度。不凭直觉加规则，用历史数据驱动
证据：anti-patterns.md 变更前 16 条子模式仅 ~6 条命中历史事故，新增 7 条精确对齐 20 次独立事故，覆盖率跃升至 ~87%

### 🐶 [DG-84] 文档框架升级必须评估「可物化性」— 区分可 hook 化和设计流程问题 (@LuangSir)

@2026-05-17 hits:1
触发条件：新增反模式/规则后未评估能否被自动检测拦截
正确行为：每条新规则附加「可物化性」评级。可直接 hook 拦截（如 I1 零命中告警、J2 bash -n 验证、L1 pipefail）→ 优先实现；属于设计流程问题（如 I2 软约束、K2 审查衰减）→ 标记为流程约束，不投入 hook 化资源。资源永远先投向可自动检测的项
证据：4/7 新子模式可被现有 hook 部分覆盖（posttool-bash-audit 覆盖 I1/J2/L1，posttool-subagent-audit 覆盖 K1），I2/K2 标记为设计流程问题

### 🐶 [DG-85] 新增反模式类别必须附带狗粮证据链 — 每条子模式追溯具体 DG/ED/DF 编号 (@LuangSir)

@2026-05-17 hits:1
触发条件：写反模式描述时用模糊语言（「源自 7+ 次独立事故」）但未列出具体编号
正确行为：每条新反模式子模式的「狗粮证据」字段必须列出具体 DG/ED/DF 编号，不可用「多次事故」「多次触发」等模糊表述。证据链让后来者可以追溯原始事故，判断该反模式是否仍然活跃
证据：I1 证据链: ED-01/DG-25/DG-30/DG-74/DG-82；I2: DG-09/DG-47/DG-62/DG-58；J1: DG-33/DF-04/DG-68/DG-80；J2: DG-80；K1: DG-44/DG-63/DG-61/DG-67；K2: DG-61/DG-64/DG-67；L1: DG-36/DG-54/DG-60/DG-32

### 🐶 [DG-007] JSON 修复用 roundtrip 而非 raw text replace —— 多层转义陷阱 (@lucas.liang)

@2026-05-17 hits:1
触发条件：当 jsonl/json 文件中存在需要修改的字面文本时
正确行为：不要用字符串替换操作修改 JSON 文件内容。正确做法：parse JSON → 递归修改 decoded Python 对象中的字符串值 → json.dumps 重新序列化。JSON 中 `U+D800`（valid escaped）和 `U+D800`（invalid escape）在原始字节层面有不同数量的反斜杠，raw text replace 容易只替换部分导致残留
证据：修复 lone surrogate API 400 错误时，raw text replace 在 transcript 遗留 13 处未替换，改用 JSON roundtrip 后一次清除

### 🐶 [DG-008] 跨 session bug 需追踪 hook 注入链 —— error-signals 是隐藏传播源 (@lucas.liang)

@2026-05-17 hits:1
触发条件：bug 在新 session/终端中反复出现时
正确行为：不仅检查当前 session 的 jsonl，还要检查：(1) `.omc/state/error-signals.jsonl` — hook 注入的 `<system-reminder>` 源 (2) `~/.claude/transcripts/*.jsonl` — OpenCode session transcript (3) 子 agent 的 `subagents/` 目录 (4) 任何 hook 脚本引用并注入的文件
证据：修复了当前 session 后 bug 仍复发，追踪到 error-signals.jsonl (6 处) 和 transcript (66 处) 后彻底解决

### 🐶 [DG-009] AI 诊断输出会自指复现 bug —— 避免在诊断文本中引用 bug 模式 (@lucas.liang)

@2026-05-18 hits:2
触发条件：AI assistant 在诊断问题时，回复中包含与 bug 模式相同的字面文本
正确行为：诊断时避免在回复中直接包含触发 bug 的字面文本。使用替代表示法（如用 `U+D800` 表示代理对字符，`&lt;` 代替 `<` 等），防止"解释 bug → 回复中包含 bug 模式 → 下轮请求触发同一个 bug"的自指循环。**即使 `U+D800` 看似安全（6 个 ASCII 字符），DeepSeek API bridge 的序列化链路会将无转义的反斜杠吞掉，使 `U+D800` 字面文本被 JSON parser 解释为孤代理转义**
证据：2026-05-18: 本对话 3 轮连续触发。AI 修复 DG-008-v4 后在验证报告中大量使用 `U+D800`/`U+D800` 字面量，20 分钟后同一会话触发 same error（messages[16].content[3].text）。**即使使用 `U+D800`（不带反斜杠）也可能触发**，因为风险不在你是否写反斜杠，而在 API bridge 是否吃掉了反斜杠。**最佳策略：讨论 Unicode 问题时全程使用 `U+xxxx` 或 `0xD800` 等不包含 `\u` 序列的纯字母数字表示法**

### 🐶 [DG-86] Oracle 超时必须有降级协议 — 不能直接跳自检代替裁决 (@LuangSir)

@2026-05-17 hits:1
触发条件：Oracle agent 超时/失败未返回裁决时，AI 直接用自检代替 Oracle 裁决
正确行为：Oracle 超时/失败 → 不直接自检代替 → 触发 Meta-Oracle 终审（G3 路径）→ Meta-Oracle 裁决为最终裁决。DG-67 要求机制变更必须 Oracle+Meta-Oracle 双签，自检不是 Oracle 的合法替代品
证据：本次 Oracle agent 超时后直接自检，违反 DG-67 双签要求，需补 Meta-Oracle 终审纠正

### 🐶 [DG-87] Meta-Oracle agent 执行路径需要 API bug fallback — 手动方法论降级路径 (@LuangSir)

@2026-05-18 hits:2
触发条件：Meta-Oracle agent 因 API 级错误（lone surrogate / context overflow 等）无法完成时
正确行为：Meta-Oracle agent 失败 → 不放弃终审 → 降级为手动执行 Meta-Oracle 运行时方法论：(1) 独立逐项验证而非依赖 agent 上下文 (2) 运行时验证 > 静态检查 (3) 对抗性审查 > 合规检查 (4) 裁决留痕到 meta-oracle-verdicts.md
证据：2026-05-18: Meta-Oracle agent 再次遭遇 lone surrogate API 400 错误，11 次 tool_use 后 API serialization 失败。按 DG-87 fallback 手动完成评分。本次评分结果：C 8.78/10, E 7.96/10, 治理 8.07/10, 综合 8.37/10

### 🐶 [DG-88] json.dumps(ensure_ascii=False) 产出 \\uDxxx 被 DeepSeek parser 拒绝 — 需在 json.dumps 前 strip 代理对实际字符 (@LuangSir)

@2026-05-18 hits:1
触发条件：error-dna.sh / stop-drain.sh 中使用 json.dumps(record, ensure_ascii=False) 写入 JSONL 时，record 中存在 U+D800..U+DFFF 字符
正确行为：json.dumps 无论如何（ensure_ascii=True/False）都会将 U+D800..U+DFFF 序列化为 \\uDxxx。这不是 text replace 能覆盖的（text replace 防的是字面 `\uDxxx` 文本模式），必须 **在 json.dumps 调用前 strip 代理对字符**：`''.join(c for c in s if not 0xD800 <= ord(c) <= 0xDFFF)`
证据：error-dna.sh 和 stop-drain.sh 已有针对字面 `\\uDxxx` 文本的 regex sanitizer（DG-008-v3），但从未被触发（sanitizer-log.jsonl 不存在）。实际问题是模型产出含实际 U+D800 字符，json.dumps 序列化产生 `\\uDxxx` 转义。修复：添加 `_strip_surrogates()` 函数在 json.dumps 前 strip 所有代理对字符。修了 error-dna.sh + stop-drain.sh，同步到 source/harness-kit

---

### [2026-05-17] 用户纠正: 不对
@2026-05-17 hits:1
**触发场景**：检测到纠正信号「不对」（你错了，这个不对）
**问题**：（待本对话补充具体纠正内容）
**纠正**：（AI 完成任务前应引用此记录并补充根因分析）


### [2026-05-18] 用户纠正: 不对
@2026-05-18 hits:1
**触发场景**：检测到纠正信号「不对」（你错了，这个不对）
**问题**：（待本对话补充具体纠正内容）
**纠正**：（AI 完成任务前应引用此记录并补充根因分析）


### [2026-05-19] 用户纠正: 不对
@2026-05-19 hits:1
**触发场景**：检测到纠正信号「不对」（你错了，这个不对）
**问题**：（待本对话补充具体纠正内容）
**纠正**：（AI 完成任务前应引用此记录并补充根因分析）

---

## 2026-05-19 狗粮 — Oracle Agent v2 物理隔离机制

### 🐶 [DG-89] Oracle Agent 必须物理隔离 — 同上下文 AI 无法独立审核自己 (@LuangSir)

@2026-05-19 hits:1
触发条件：任何声称「独立审核」但使用 Skill 工具注入 prompt 的机制
正确行为：独立 Oracle 审核必须通过 Agent(critic, opus) spawn 独立进程，拥有独立上下文窗口。Skill 工具注入 = 同模型同上下文 = I2 软约束幻觉。
证据：R1/R2/Meta-Oracle 3 轮独立 Agent 发现 26+ 缺陷完全不重叠 — 证明同上下文自审无法覆盖。旧 lx-oracle 是 61 行纯 prompt skill，零物理隔离。

### 🐶 [DG-90] bash→Python 变量注入危险 — 用 base64 + heredoc 环境变量传递 (@LuangSir)

@2026-05-19 hits:1
触发条件：Shell 脚本中用 `python3 -c "...$var..."` 传递 bash 变量到 Python 字符串字面量
正确行为：用 base64 编码内容传入 stdin，Python 侧解码；JSON 数据用环境变量 + heredoc（`<<'PYEOF'`）传递。禁止 bash 变量直接拼接到 Python 字符串中。
证据：oracle-spawn.sh 修复前：单引号路径导致 `SyntaxError: unterminated string literal` 崩溃；三引号 `'''` 在文件内容中出现导致字符串终止。

### 🐶 [DG-91] 决策链应自主修复 — 收到审查结果后直接修，不问「要修吗」(@LuangSir)

@2026-05-19 hits:1
触发条件：Oracle 独立审核返回 REJECT/REVISE 裁决时，AI 问「要修吗？」而非直接执行修复
正确行为：[哲学先行: #2 少量正确大增益 → AI 直接修复→重审循环，不打断用户]。审查发现明确的、可自动修复的缺陷时，AI 应自主判断修复必要性并直接执行，仅在不明确或高风险时问用户。
证据：本对话中用户说「明知故问」和「你没有决策链支持你做决策吗？」两次纠正。

---

## 2026-05-19 狗粮 — Phase 1-4 系统性优化

### 🐶 [DG-93] 单一 agent 输出不可信 — 关键数值必须独立交叉验证 (@LuangSir)

@2026-05-19 hits:1
触发条件：AI/子 Agent 对同一个 grep 命令返回不同结果时；任何涉及计数的关键数据
正确行为：凡涉及计数的关键数据（hook 数量、flywheel 覆盖率、文档数），必须 (a) 物理执行 grep/ls/wc -l (b) 对比 AI 声称值 vs 实际输出 (c) 不一致时以物理结果为准。本次 flywheel 埋点率从 7→26→40 经过 3 轮独立验证才收敛。
证据：Phase 1: Agent 声称 42 hooks → 实际 44; Phase 2: grep 输出被截断 → 声称 7 而非实际 26; Phase 4h.1: 物理 sed 补全 14 个 → 最终 40/42 (95%)

### 🐶 [DG-94] 决策矩阵必须交叉验证哲学-机制矩阵 — 不能仅凭 ROI 数字做去留判断 (@LuangSir)

@2026-05-19 hits:1
触发条件：当 ROI 评分与其他维度（哲学/铁律/原始意图）冲突时
正确行为：去留决策层级: 哲学 > 铁律 > 原始意图 > ROI。ROI=0 可能只是数据缺失（无 flywheel 埋点），而非无价值。Oracle #2 发现 pretool-ask-guard (ROI=0) 被误归类为 ❌❌❌ 删除候选，实际有哲学 #5,#6 + 铁律 #8 支撑。
证据：pretool-ask-guard: 哲学 #5,#6 + 铁律 #8 — 哲学先行门禁; compact-detect: 哲学 #1,#3

### 🐶 [DG-95] 统计汇总表必须区分「未检查」与「分歧」— 观测基础设施不完整 ≠ 组件质量差 (@LuangSir)

@2026-05-19 hits:1
触发条件：当大量组件 Source III 数据缺失时
正确行为：汇总表必须有三个独立列 — ✅ 一致 / ⚠️ 分歧 / ⛔ 未检查。Phase 2 最初将 348/379 组件的 Source III 盲区标记为「⚠️ 分歧」，实际 78% 是「⛔ 未检查」。混淆导致「7% 通过三源验证」的误导性结论。
证据：phase2-report.md v1.0 vs v1.1: 添加 ⛔ 未检查列后，结论从'92% 分歧'改为'78% 未检查, 14% 分歧'

### 🐶 [DG-92] 渐进式披露 — Skill body 应是最小路由决策表 (@LuangSir)

@2026-05-19 hits:1
触发条件：Skill SKILL.md 超过 100 行，包含完整协议细节和 YAML schema
正确行为：SKILL.md body ≤60 行：路由决策表 + 3 步执行框架 + 外部引用指针。详细协议、YAML schema、故障恢复全部外移到 references/，仅在 spawn Agent 时按需注入。
证据：lx-oracle-v2 SKILL.md 从 217 行优化到 53 行（-75%），protocol.md 按需加载。前端展示仅路由表 + 3 步命令，细节隐藏。

