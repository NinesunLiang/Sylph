#!/usr/bin/env bash
# posttool-claim-audit.sh — PostToolUse:Edit|Write — 铁律 #1「禁止编造」强制校验
# 检测 AI 对文件内容的断言（file:line 引用）是否基于真实读取
# Role: 铁律 #1 enforce — AI 不能编造没读过的代码事实

source "$(dirname "$0")/harness_config.sh"
hc_enabled "posttool_claim_audit" || { echo '{"continue": true}'; exit 0; }

# Mode detection: ghost/goal 降级为 log+skip
_MODE=$(is_mode_active "$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)/.omc/state")
if [ "$_MODE" != "normal" ]; then
    echo "[$_MODE] posttool-claim-audit 已记录（模式降级，不阻断）" >&2
    echo '{"continue": true}'
    exit 0
fi

INPUT=$(cat)
TOOL_NAME="$1"

# 仅审计 Edit/Write — AI 输出代码断言的主要出口
case "$TOOL_NAME" in
    Edit|Write) ;;
    *) exit 0 ;;
esac

# 提取 file_path（工具输入）
if command -v jq &>/dev/null; then
    FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // empty' 2>/dev/null)
else
    FILE_PATH=$(echo "$INPUT" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    print(data.get('tool_input', {}).get('file_path', ''))
except:
    pass" 2>/dev/null)
fi

# 无路径 → 放行（避免误杀）
[ -z "$FILE_PATH" ] && exit 0

# 提取文件绝对路径用于 read-tracker 比对
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
STATE_DIR="$PROJECT_ROOT/.omc/state"
READ_LOG="$STATE_DIR/read-tracker.txt"

# 提取所有 file:line 引用（AGENTS.md:42, kernel.go:15, .claude/hooks/plan-gate.sh:15）
# 修复: 不再要求以 . 开头（之前漏掉了 AGENTS.md:42 等裸文件名引用）
CLAIMED_FILES=$(echo "$INPUT" | grep -oE '(\.?/)?[a-zA-Z0-9_./-]+\.[a-z]+:[0-9]+' | sed 's|^\./||' || true)
if [ -z "$CLAIMED_FILES" ]; then
    exit 0
fi

# 读取 read-tracker（可能跨轮次累积）
read_files=""
if [ -f "$READ_LOG" ]; then
    read_files=$(cat "$READ_LOG")
fi

# 检测 claim 文件是否在 read-tracker 中
CLAIMED_BASENAMES=$(echo "$CLAIMED_FILES" | sed 's|:.*||' | xargs -I{} basename {} 2>/dev/null | sort -u || true)
CLAIMED_DIRS=$(echo "$CLAIMED_FILES" | sed 's|:.*||' | xargs -I{} dirname {} 2>/dev/null | sort -u || true)

VIOLATIONS=""
while IFS= read -r claimed; do
    [ -z "$claimed" ] && continue

    # Strip line number suffix (:NNN) for path comparison
    claimed_path=$(echo "$claimed" | sed 's/:[0-9]*$//')

    # 检查1: read-tracker 中有完整路径匹配
    if echo "$read_files" | grep -qxF "$(realpath "./$claimed_path" 2>/dev/null || echo "$claimed_path")"; then
        continue
    fi

    # 检查2: basename 匹配（同一文件被多次 Read）
    if echo "$read_files" | grep -qF "/$(basename "$claimed_path")"; then
        continue
    fi

    # 检查3: dirname 下有同名文件被 Read（包级引用）
    set -f
    for dir in $CLAIMED_DIRS; do
        if echo "$read_files" | grep -qF "$dir/$(basename "$claimed_path")"; then
            set +f
            continue 2
        fi
    done
    set +f

    VIOLATIONS="${VIOLATIONS}⚠️ IRRELEVANT_CLAIM: ${claimed}\n"
done <<< "$CLAIMED_FILES"

# === G1 伪诚信剧场检测: 自创指标无行业标准来源 ===
G1_VIOLATIONS=""
PCT_CLAIMS=$(echo "$INPUT" | grep -oE '[0-9]{1,3}\.[0-9]+%|[0-9]{1,3}%|通过率' 2>/dev/null || true)
if [ -n "$PCT_CLAIMS" ]; then
    HAS_SOURCE=$(echo "$INPUT" | grep -ciE '(ASVS|OWASP|NIST|ISO|CWE|CVE|ATLAS|benchmark|baseline|\[已验证|\[已测试|内部自检)' 2>/dev/null || echo 0)
    if [ "$HAS_SOURCE" -eq 0 ]; then
        G1_SAMPLE=$(echo "$PCT_CLAIMS" | head -3 | tr '\n' ' ')
        G1_VIOLATIONS="⚠️ G1_PSEUDO_INTEGRITY: 百分比/评分(${G1_SAMPLE})无行业标准来源。请标注 [内部自检，非行业标准] 或附加来源 URL/file:line。"
    fi
fi

if [ -n "$VIOLATIONS" ] || [ -n "$G1_VIOLATIONS" ]; then
    COMBINED="${VIOLATIONS}${G1_VIOLATIONS:+\n${G1_VIOLATIONS}}"
    printf '{"continue": false, "hookSpecificOutput": {"additionalContext": "⛔ [铁律#1+#7] AI 输出真实性违规:\n'"${COMBINED}"'\n宪法: \"禁止编造\" + \"百分比/评分必须有行业标准来源\"\n请修复以上违规项后重试。"}}\n'
    exit 2
fi

exit 0
