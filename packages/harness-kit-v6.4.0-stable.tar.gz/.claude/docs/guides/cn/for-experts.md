# 面向专家

> **你来这里不是为了护栏，而是为了力量倍增器。**

## 变化了什么

**进阶版**解锁完整的 Carror OS — 主动工作流、多智能体盲审、DLP 透明代理和 RPE 开发管线。

安装方式：

```bash
curl -fsSL https://raw.githubusercontent.com/NinesunLiang/Sylph/main/install.sh | bash -s -- enhanced
```

## 你将获得（超越基础版）

### 执行模式

| 技能 | 功能 |
| :--- | :--- |
| `/lx-ghost` | 方向驱动自主探索 — 给方向，AI 增量迭代，安全网降级不干扰 |
| `/lx-goal` | 目标驱动自主执行 — 给目标，AI 执行到完，完成后出报告 |

### 任务管理（复杂度递增）

| 技能 | 复杂度 | 功能 |
| :--- | :--- | :--- |
| `/lx-todo` | L1 | 轻量 5 步循环：捕获→分诊→修复→验证→关闭（≤3 文件） |
| `/lx-task-spec` | L2 | 3 问引导 → AC 驱动，中等复杂度，不需完整 PRD |
| `/lx-rpe` | L3 | 研究→规划→执行管线，50% 上下文交接 + A/B 盲审 |

### OMA 一人成军管线

| 技能 | 功能 |
| :--- | :--- |
| `/lx-oma-hier` | 超大型 PRD 按功能域 MECE 拆分为 Sub PRD |
| `/lx-oma-split` | Sub PRD 拆解为正交 feature 分支 |
| `/lx-oma-orch` | 管线编排：状态查看/阶段推进/Oracle 门禁/并行管理 |
| `/lx-oma-gov` | PRD 治理：增量同步/冲突裁决/漂移检测 |

### 质量门禁

| 技能 | 功能 |
| :--- | :--- |
| `/lx-pre-commit` | 提交前：项目类型检测 → 编译 → 测试 → 代码审查 |
| `/lx-pre-push` | 推送前：commit message 校验 → 测试覆盖 → 安全扫描 → 判定 |

### 审查层级

| 审查者 | 定位 | 触发频率 | 门禁类型 |
| :--- | :--- | :--- | :--- |
| **Oracle** | 常规守门员 — 每阶段方案审核 + 终审 | L2+ 每阶段 | 硬门禁（REJECT = 阻断） |
| **Meta-Oracle** | 最后守门员（核武器级）— G1-G4 关键节点触发 | ~5% 任务 | 软门禁（可覆写，需留痕） |

> Meta-Oracle 是 Carror OS 的最高审查权威，消耗巨大（opus + 独立上下文），非必要不使用。Oracle 是日常站岗的守门员，Meta-Oracle 是只在关键时刻请出来的最后守门员。

### 代码质量

| 技能 | 审查对象 | 规则 |
| :--- | :--- | :--- |
| `/lx-code-review` | 通用代码 | 8 类 39 条（错误处理/并发/接口/性能/可观测性） |

### 测试与调试

| 技能 | 功能 |
| :--- | :--- |
| `/lx-test-gen` | 语言无关测试生成（Go/TS/Python 自动检测） |
| `/lx-root-cause-analysis` | 5-Why 根因追踪 + 证据链 + 置信度评分 |

### 基础设施

| 技能 | 功能 |
| :--- | :--- |
| `/lx-status` | 健康面板 v3.0：Token 节省/任务通过率/拦截错误/知识点 |
| `/lx-varlock` | DLP 透明代理 — 敏感信息绝不泄露到 AI 上下文 |
| `/lx-race` | 蜂群协调：注册子任务→派发→收集→报告 |

> 完整技能目录（含触发词、选择指南、关系图谱）见 [技能目录](skills-catalog.md)。

### RPE 工作流

核心专家工作流是**研究→规划→执行**：

1. **研究**：调查问题空间、记录约束、读取受影响代码
2. **规划**：设计架构、定义接口、设定验收标准
3. **执行**：每一步都有证据门禁的增量实现，50% 时自动上下文交接

## 何时升级

当你满足以下条件时从基础版升级到进阶版：

- 正在承担跨多个模块的复杂重构
- 需要多智能体盲审来发现自己的盲区
- 希望为大型功能开发建立结构化的 RPE 规范
- 需要管理同时在代码库不同部分工作的并发 AI 智能体

升级是安全的，原地进行。你现有的配置和记忆将被保留：

```bash
bash install.sh enhanced
```

降级也同样安全：

```bash
bash install.sh base
```

## 下一步

| 目标 | 路径 |
| :--- | :--- |
| RPE 深度了解 | [工作流概念](../concepts/workflow.md) |
| 完整功能参考 | [功能特性](../governance/features.md) |
| 升级说明 | [版本选择](../governance/editions.md) |


## 5-Phase Structured Execution Protocol
非trivial任务自动走: 调研→方案双审→无人执行→结果双审→验收报告。`.claude/reference/structured-execution-protocol.md`
