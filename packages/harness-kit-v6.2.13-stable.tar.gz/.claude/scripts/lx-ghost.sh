#!/usr/bin/env bash
# lx-ghost.sh — 幽灵模式（方向驱动自主探索）
# 用法: lx-ghost on|off|status|set <key> <value>|poll
# 幽灵模式: 给 AI 一个"方向"，AI 自主探索并修复，不干扰人，默认 3h 过期
# 与 lx-goal 的区别: ghost = 方向驱动（开源探索），goal = 目标驱动（具体任务）
# 同时创建 autonomous.active 信号供所有 hook 降级
#
# 哲学映射:
#   #3 先守护: gate 降级为 warn-only 而非硬阻断
#   #4 没验证=没做: poll 报告 + completion 软评分
#   #6 0信任: 危险操作记录 skipped_risks 而不是跳过

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../../../.." && pwd)"
STATE_DIR="$PROJECT_ROOT/.omc/state"
mkdir -p "$STATE_DIR" 2>/dev/null

# source harness_config for hc_get defaults
source "$SCRIPT_DIR/../../../hooks/harness_config.sh"

MODE_FILE="$STATE_DIR/lx-ghost.json"

# 智能参数检测：第一个参数不是已知子命令 → 当作方向描述自动激活
_KNOWN_SUBCOMMANDS="on|off|status|set|poll|report|skip-risk|hard-boundary-hit|retry"
if [ -n "${1:-}" ] && ! echo "$1" | grep -Eq "^($_KNOWN_SUBCOMMANDS)$"; then
    exec bash "$0" on "$@"
fi

case "${1:-status}" in
    on)
        DIRECTION="${2:-自主探索和修复系统问题}"
        INTERVAL="${3:-$(hc_get "ghost_mode.default_poll_interval" "600")}"
        EXPIRY_HOURS="${4:-$(hc_get "ghost_mode.default_expiry_hours" "3")}"
        MIN_ITERS="${5:-$(hc_get "ghost_mode.default_min_iterations" "0")}"
        EXPIRES=$(python3 -c "from datetime import datetime,timedelta; print((datetime.now()+timedelta(hours=$EXPIRY_HOURS)).isoformat())" 2>/dev/null)
        # 原子写入 lx-ghost.json
        tmp="${MODE_FILE}.tmp.$$"
        cat > "$tmp" <<JSON
{
  "active": true,
  "mode": "ghost",
  "direction": "$DIRECTION",
  "cycle_interval_seconds": $INTERVAL,
  "expires_at": "$EXPIRES",
  "activated_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "min_iterations": $MIN_ITERS,
  "iterations_completed": 0,
  "retry_count": 0,
  "skipped_risks": []
}
JSON
        mv -f "$tmp" "$MODE_FILE" 2>/dev/null
        # 创建 autonomous.active 信号供 completion-gate 等降级
        touch "$STATE_DIR/autonomous.active"
        # B3: flywheel telemetry
        mkdir -p "$HOME/.claude" 2>/dev/null
        echo "$(date +%Y-%m-%d),ghost_activated,P2,$(basename "$PROJECT_ROOT" 2>/dev/null || echo unknown)" >> "$HOME/.claude/flywheel-buffer.jsonl"
        # B5: sticky marker for crash detection
        date -u +%Y-%m-%dT%H:%M:%SZ > "$STATE_DIR/ghost-session-active-at"
        # 清理旧格式文件
        rm -f "$STATE_DIR/.unattended-mode" "$STATE_DIR/ghost-mode.active" 2>/dev/null
        echo "✅ 幽灵模式已开启 — 方向: $DIRECTION, 每 ${INTERVAL}s 轮询, ${EXPIRY_HOURS}h 过期"
        echo "   autonomous.active 信号已创建，evidence/completion gate 降级为 warn-only"
        echo "   调用 /loop ${INTERVAL}s lx-ghost poll 驱动探索轮次"
        echo "   或 /lx-ghost on \"继续\" — 在同一次会话内继续探索"
        echo ""
        # 将决策链注入 AI 上下文（Oracle M1: 确保模式激活时 AI 立即看到决策链）
        DECISION_CHAIN="$PROJECT_ROOT/.claude/reference/autonomous-decision-chain.md"
        if [ -f "$DECISION_CHAIN" ]; then
            echo "[.claude/reference/autonomous-decision-chain.md]"
            cat "$DECISION_CHAIN"
            echo ""
        fi
        echo ""
        echo "📋 退出报告模板（完成探索后使用 lx-ghost report '...' 提交）："
        echo ""
        echo "## 探索摘要"
        echo "（方向、轮次、关键发现）"
        echo ""
        echo "## 已完成操作"
        echo "（逐项列出 + Before/After 对比）"
        echo ""
        echo "## ⚠️ 需人类介入项（硬边界）"
        echo "（被硬边界跳过的操作 + 原因 + 建议人类操作）"
        echo ""
        echo "## 已跳过风险"
        echo "（skip-risk 记录项）"
        echo ""
        echo "## 附带发现"
        echo "（范围外问题）"
        echo ""
        ;;

    off)
        FORCE="${2:-}"
        EXIT_REPORT="$STATE_DIR/ghost-exit-report.md"
        
        if [ "$FORCE" != "--force" ]; then
            if [ ! -f "$EXIT_REPORT" ]; then
                echo "🛑 幽灵模式关闭被阻止 — 未找到退出报告" >&2
                echo "" >&2
                echo "   在关闭幽灵模式前，你必须先完成退出报告：" >&2
                echo "     1. 在对话中按 SKILL.md 退出报告结构生成报告" >&2
                echo "     2. 执行: lx-ghost report '你的完整报告内容'" >&2
                echo "     3. 或: 使用 lx-ghost report 生成报告后再重试" >&2
                echo "" >&2
                echo "   紧急绕过: lx-ghost off --force（报告将在下次 SessionStart 提醒补交）" >&2
                exit 1
            fi
            
            # 验证报告完整性：必须包含 5 个必填章节
            MISSING=""
            grep -q '探索摘要' "$EXIT_REPORT" 2>/dev/null || MISSING="$MISSING 探索摘要"
            grep -q '已完成操作' "$EXIT_REPORT" 2>/dev/null || MISSING="$MISSING 已完成操作"
            grep -q '需人类介入' "$EXIT_REPORT" 2>/dev/null || MISSING="$MISSING 需人类介入"
            grep -q '已跳过风险' "$EXIT_REPORT" 2>/dev/null || MISSING="$MISSING 已跳过风险"
            grep -q '附带发现' "$EXIT_REPORT" 2>/dev/null || MISSING="$MISSING 附带发现"
            
            if [ -n "$MISSING" ]; then
                echo "🛑 退出报告不完整 — 缺少必填章节:${MISSING}" >&2
                echo "   请补充缺失章节后重试 lx-ghost off" >&2
                exit 1
            fi
        else
            echo "⚠️  强制关闭（--force），跳过了退出报告检查" >&2
            # 留下提醒桩供下次 SessionStart 检测
            touch "$STATE_DIR/ghost-exit-pending" 2>/dev/null
            # B3: flywheel telemetry
            mkdir -p "$HOME/.claude" 2>/dev/null
            echo "$(date +%Y-%m-%d),ghost_forced_close,P1,$(basename "$PROJECT_ROOT" 2>/dev/null || echo unknown)" >> "$HOME/.claude/flywheel-buffer.jsonl"
        fi
        
        if [ -f "$MODE_FILE" ]; then
            rm -f "$MODE_FILE"
        fi
        # 清理旧格式文件
        rm -f "$STATE_DIR/ghost-mode.json" "$STATE_DIR/ghost-mode.active" 2>/dev/null
        rm -f "$STATE_DIR/autonomous.active" "$STATE_DIR/ghost-session-active-at" 2>/dev/null
        echo "✅ 幽灵模式已关闭，所有 hook 恢复正常阻断"
        if [ -f "$EXIT_REPORT" ]; then
            echo "   退出报告: $EXIT_REPORT"
        fi
        if [ "$FORCE" != "--force" ]; then
            # 正常关闭：清理 pending 桩 + 飞轮 completed 事件
            rm -f "$STATE_DIR/ghost-exit-pending" 2>/dev/null
            mkdir -p "$HOME/.claude" 2>/dev/null
            echo "$(date +%Y-%m-%d),ghost_completed_with_report,P2,$(basename "$PROJECT_ROOT" 2>/dev/null || echo unknown)" >> "$HOME/.claude/flywheel-buffer.jsonl"
        fi
        echo "   提示: 如有 CronCreate 轮询作业，请执行 CronDelete <job_id> 清理。"
        ;;

    status)
        if [ -f "$MODE_FILE" ]; then
            DIR=$(python3 -c "import json; d=json.load(open('$MODE_FILE')); print(d.get('direction','?'))" 2>/dev/null)
            EXP=$(python3 -c "import json; d=json.load(open('$MODE_FILE')); print(d.get('expires_at','无'))" 2>/dev/null)
            INT=$(python3 -c "import json; d=json.load(open('$MODE_FILE')); print(d.get('cycle_interval_seconds','?'))" 2>/dev/null)
            RETRY=$(python3 -c "import json; d=json.load(open('$MODE_FILE')); print(d.get('retry_count',0))" 2>/dev/null)
            SKIP=$(python3 -c "import json; d=json.load(open('$MODE_FILE')); print(len(d.get('skipped_risks',[])))" 2>/dev/null)
            HARD=$(python3 -c "import json; d=json.load(open('$MODE_FILE')); print(len(d.get('hard_boundary_hits',[])))" 2>/dev/null)
            echo "📋 幽灵模式 (lx-ghost): 🟢 开启中"
            echo "   方向: $DIR"
            echo "   间隔: ${INT}s"
            echo "   过期: $EXP"
            echo "   重试: $RETRY  跳过风险: $SKIP  硬边界: $HARD"
        elif [ -f "$STATE_DIR/ghost-mode.json" ]; then
            echo "📋 幽灵模式 (旧格式 ghost-mode.json): 🟡 兼容中"
            echo "   建议执行 lx-ghost off && lx-ghost on \"方向\" 迁移到新格式"
        else
            echo "📋 幽灵模式 (lx-ghost): ⚪ 已关闭"
        fi
        if [ -f "$STATE_DIR/autonomous.active" ]; then
            echo "   autonomous.active 信号: ✅ 存在"
        fi
        ;;

    set)
        KEY="$2"
        VALUE="$3"
        if [ ! -f "$MODE_FILE" ]; then
            echo "❌ 幽灵模式未开启，无法修改"
            exit 1
        fi
        python3 -c "
import json, os
file = '$MODE_FILE'
d = json.load(open(file))
d['$KEY'] = $VALUE
tmp = file + '.tmp.' + str(os.getpid())
with open(tmp, 'w') as f:
    json.dump(d, f, indent=2, ensure_ascii=False)
os.rename(tmp, file)
" 2>/dev/null && echo "✅ 幽灵模式 $KEY 已更新为 $VALUE" || echo "❌ 更新失败"
        ;;

    poll)
        # 幽灵模式轮询入口 — 由 loop skill / ralph-loop 调用
        if [ ! -f "$MODE_FILE" ]; then
            # 回退检查旧格式
            if [ -f "$STATE_DIR/ghost-mode.json" ]; then
                DIR=$(python3 -c "import json; d=json.load(open('$STATE_DIR/ghost-mode.json')); print(d.get('direction','?'))" 2>/dev/null)
                echo "⚠️ 旧格式 ghost-mode.json 存在，建议迁移: lx-ghost off && lx-ghost on \"$DIR\""
            else
                echo "❌ 幽灵模式未激活，停止轮询"
            fi
            exit 1
        fi

        # 检查过期
        EXPIRES=$(python3 -c "import json; d=json.load(open('$MODE_FILE')); print(d.get('expires_at',''))" 2>/dev/null)
        if [ -n "$EXPIRES" ]; then
            EXPIRED=$(python3 -c "
from datetime import datetime
try:
    exp = datetime.fromisoformat('$EXPIRES')
    print('yes' if datetime.now() > exp else 'no')
except: print('no')" 2>/dev/null)
            if [ "$EXPIRED" = "yes" ]; then
                echo "⏰ 幽灵模式已过期（$EXPIRES），自动关闭"
                touch "$STATE_DIR/ghost-exit-pending" 2>/dev/null
                # B3: flywheel telemetry (expired, not forced)
                mkdir -p "$HOME/.claude" 2>/dev/null
                echo "$(date +%Y-%m-%d),ghost_expired_no_report,P1,$(basename "$PROJECT_ROOT" 2>/dev/null || echo unknown)" >> "$HOME/.claude/flywheel-buffer.jsonl"
                rm -f "$MODE_FILE" "$STATE_DIR/autonomous.active" 2>/dev/null
                exit 0
            fi
        fi

        echo "=== 幽灵轮询 [$(date -u +%Y-%m-%dT%H:%M:%SZ)] ==="
        DIR=$(python3 -c "import json; d=json.load(open('$MODE_FILE')); print(d.get('direction','?'))" 2>/dev/null)
        RETRY=$(python3 -c "import json; d=json.load(open('$MODE_FILE')); print(d.get('retry_count',0))" 2>/dev/null)
        SKIP=$(python3 -c "import json; d=json.load(open('$MODE_FILE')); print(len(d.get('skipped_risks',[])))" 2>/dev/null)
        echo "  方向: $DIR"
        echo "  重试次数: $RETRY  已跳过风险: $SKIP  硬边界: $(python3 -c "import json; d=json.load(open('$MODE_FILE')); print(len(d.get('hard_boundary_hits',[])))" 2>/dev/null)"

        # 状态面板：检查活跃特征 + 未提交变更
        if [ -d "$PROJECT_ROOT/rpe" ]; then
            ACTIVE=$(ls "$PROJECT_ROOT/rpe/" 2>/dev/null | head -5 | tr '\n' ' ')
            [ -n "$ACTIVE" ] && echo "  活跃特征: $ACTIVE"
        fi
        MODIFIED=$(cd "$PROJECT_ROOT" && git diff --name-only 2>/dev/null | head -10 | tr '\n' ' ')
        [ -n "$MODIFIED" ] && echo "  未提交变更: $MODIFIED"

        # 集成 retry-budget.sh 状态检查
        RETRY_SCRIPT="$SCRIPT_DIR/retry-budget.sh"
        if [ -f "$RETRY_SCRIPT" ]; then
            RETRY_CTX=$(bash "$RETRY_SCRIPT" check 2>&1)
            RETRY_EXIT=$?
            if [ $RETRY_EXIT -eq 2 ] && [ -n "$RETRY_CTX" ]; then
                echo "⚠️ [Retry Budget BLOCKED] 以下错误已达 3 次上限，需人工干预:"
                echo "$RETRY_CTX" | head -5
            elif [ $RETRY_EXIT -eq 0 ]; then
                echo "  retry-budget: 正常"
            fi
        fi

        # 四维评分检查（如果项目有评分机制）
        SCORE_SCRIPT="$SCRIPT_DIR/auto-score.sh"
        if [ -f "$SCORE_SCRIPT" ]; then
            echo "  评分检查: 可用 (bash auto-score.sh)"
        fi

        echo "  命令: ${DIR}"
        echo "  自主探索并修复，发现问题自行处理（最多 3 次），无法处理的记录等待人工"
        echo "  ⚡ 注意保持方向感，不要偏离方向做无关优化"
        ;;

    report)
        # 生成退出报告（关闭幽灵模式前的强制步骤）
        REPORT_CONTENT="${2:-}"
        EXIT_REPORT="$STATE_DIR/ghost-exit-report.md"
        
        if [ -z "$REPORT_CONTENT" ]; then
            echo "用法: lx-ghost report '<markdown报告内容>'" >&2
            echo "" >&2
            echo "报告必须包含 5 个必填章节：" >&2
            echo "  ## 探索摘要  — 方向、轮次、关键发现" >&2
            echo "  ## 已完成操作 — 逐项列出" >&2
            echo "  ## ⚠️ 需人类介入项（硬边界）" >&2
            echo "  ## 已跳过风险" >&2
            echo "  ## 附带发现" >&2
            exit 1
        fi
        
        # 写入报告
        echo "$REPORT_CONTENT" > "$EXIT_REPORT"
        
        # 验证：章节存在（同 L2 off 门禁）
        MISSING=""
        grep -q '探索摘要' "$EXIT_REPORT" 2>/dev/null || MISSING="$MISSING 探索摘要"
        grep -q '已完成操作' "$EXIT_REPORT" 2>/dev/null || MISSING="$MISSING 已完成操作"
        grep -q '需人类介入' "$EXIT_REPORT" 2>/dev/null || MISSING="$MISSING 需人类介入"
        grep -q '已跳过风险' "$EXIT_REPORT" 2>/dev/null || MISSING="$MISSING 已跳过风险"
        grep -q '附带发现' "$EXIT_REPORT" 2>/dev/null || MISSING="$MISSING 附带发现"
        
        if [ -n "$MISSING" ]; then
            echo "⚠️  报告已保存，但缺少章节:${MISSING}" >&2
            echo "   请在 lx-ghost off 前补充完整" >&2
        else
            # P1: 内容质量门禁 — 每节 >= 20 非空白字符（反空壳报告，Meta-Oracle M2 修复）
            THIN=""
            for section in '探索摘要' '已完成操作' '需人类介入' '已跳过风险' '附带发现'; do
                chars=$(python3 -c "
import sys, re
text = open('$EXIT_REPORT').read()
idx = text.find('$section')
if idx < 0:
    print(0)
else:
    rest = text[idx+len('$section'):]
    end = rest.find(chr(10)+'## ')
    sect = rest[:end] if end > 0 else rest
    clean = re.sub(r'\s+', '', sect)
    print(len(clean))
" 2>/dev/null)
                if [ "${chars:-0}" -lt 20 ]; then
                    THIN="$THIN $section(${chars:-0}chars)"
                fi
            done
            if [ -n "$THIN" ]; then
                echo "⚠️  报告已保存，但以下章节内容过少（<20 非空白字符）:${THIN}" >&2
                echo "   请在 lx-ghost off 前充实内容" >&2
            else
                echo "✅ 退出报告已生成并通过章节完整性 + 内容质量验证（5/5），可以执行 lx-ghost off"
            fi
        fi
        ;;
    
        skip-risk)
        # 记录跳过的风险（供 permission-gate 等调用）
        DESCRIPTION="${2:-未知风险}"
        if [ ! -f "$MODE_FILE" ]; then
            echo "❌ 幽灵模式未开启"
            exit 1
        fi
        python3 -c "
import json, os
file = '$MODE_FILE'
d = json.load(open(file))
risks = d.get('skipped_risks', [])
risks.append({'description': '$DESCRIPTION', 'timestamp': '$(date -u +%Y-%m-%dT%H:%M:%SZ)'})
d['skipped_risks'] = risks
tmp = file + '.tmp.' + str(os.getpid())
with open(tmp, 'w') as f:
    json.dump(d, f, indent=2, ensure_ascii=False)
os.rename(tmp, file)
" 2>/dev/null && echo "📝 已记录跳过的风险: $DESCRIPTION" || echo "❌ 记录失败"
        ;;

    hard-boundary-hit)
        # 记录硬边界拦截项（rm / git写 / 敏感文件 / API Key）
        DESCRIPTION="${2:-未知硬边界}"
        REASON="${3:-未知原因}"
        HUMAN_ACTION="${4:-请人工审阅并决定是否执行}"
        if [ ! -f "$MODE_FILE" ]; then
            echo "❌ 幽灵模式未开启"
            exit 1
        fi
        python3 -c "
import json, os
file = '$MODE_FILE'
d = json.load(open(file))
hits = d.get('hard_boundary_hits', [])
hits.append({
    'description': '$DESCRIPTION',
    'reason': '$REASON',
    'human_action': '$HUMAN_ACTION',
    'timestamp': '$(date -u +%Y-%m-%dT%H:%M:%SZ)'
})
d['hard_boundary_hits'] = hits
tmp = file + '.tmp.' + str(os.getpid())
with open(tmp, 'w') as f:
    json.dump(d, f, indent=2, ensure_ascii=False)
os.rename(tmp, file)
" 2>/dev/null && echo "🛑 硬边界拦截已记录: $DESCRIPTION (原因: $REASON)" || echo "❌ 记录失败"
        ;;

    retry)
        # 增加重试计数（供 retry-budget 对接）
        if [ ! -f "$MODE_FILE" ]; then
            echo "❌ 幽灵模式未开启"
            exit 1
        fi
        python3 -c "
import json, os
file = '$MODE_FILE'
d = json.load(open(file))
d['retry_count'] = d.get('retry_count', 0) + 1
tmp = file + '.tmp.' + str(os.getpid())
with open(tmp, 'w') as f:
    json.dump(d, f, indent=2, ensure_ascii=False)
os.rename(tmp, file)
" 2>/dev/null && echo "📝 重试计数 +1（当前: $(python3 -c "import json; print(json.load(open('$MODE_FILE')).get('retry_count',0))" 2>/dev/null)）"
        ;;

    *)
        echo "用法: lx-ghost on|off|status|set|poll|skip-risk|hard-boundary-hit|retry"
        echo ""
        echo "子命令:"
        echo "  lx-ghost on \"方向描述\" [间隔秒数=600] [过期小时=3]"
        echo "    示例: lx-ghost on \"将项目四维评分提升到 90+\""
        echo "    示例: lx-ghost on \"检查所有 shell 脚本安全隐患\" 300 2"
        echo "  lx-ghost off"
        echo "  lx-ghost status"
        echo "  lx-ghost set <json_key> <json_value>"
        echo "  lx-ghost poll                    (loop skill 轮询入口)"
        echo "  lx-ghost skip-risk \"描述\"       (记录跳过的风险)"
        echo "  lx-ghost hard-boundary-hit \"操作\" \"原因\" \"需人类执行\"  (记录硬边界拦截)"
        echo "  lx-ghost retry                   (重试计数 +1)"
        echo ""
        echo "驱动方式:"
        echo "  /loop 600s lx-ghost poll         (定时轮询)"
        echo "  /ralph-loop:ralph-loop \"...\"     (自愈循环)"
        echo ""
        echo "与 lx-goal 的区别:"
        echo "  lx-ghost = 方向驱动（开源探索），lx-goal = 目标驱动（具体任务）"
        exit 1
        ;;
esac
