#!/usr/bin/env bash
# pretool-rules-inject.sh — PreToolUse — 3级分层规则注入 (v2.0)
# 哲学 #3 (先守护): 提前告知边界，用不犯错代替犯错报错
# 哲学 #5 (以人为本): 减少拦截打断，让AI提前知道规则而非事后被阻
# 永不阻断 (exit 0) — 只注入提醒，不拦截操作
#
# 3级脱水记忆分层:
#   L1 (每轮): 核心铁律 + 工具安全规则 — ≤3行，零感知负担
#   L2 (每5轮): 反模式 + 教训速查 + 软完成语禁令 — ~10行，锚定防范
#   L3 (每10轮): 完整规则 + 架构 + 命名 + 反自我矛盾 — ~25行，全量刷新

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$SCRIPT_DIR/harness_config.sh"
set -f
hc_enabled "pretool_rules_inject" || { echo '{"continue": true}'; exit 0; }

INPUT=$(cat 2>/dev/null || echo "")
TOOL_NAME=""
if command -v jq &>/dev/null && [ -n "$INPUT" ]; then
    TOOL_NAME=$(echo "$INPUT" | jq -r '.tool_name // empty' 2>/dev/null)
fi
[ -z "$TOOL_NAME" ] && { echo '{"continue": true}'; exit 0; }

# ─── 轮次读取 ───
TURNS_FILE="$PROJECT_ROOT/.omc/state/session-turns.json"
TURN_COUNT=0
if [ -f "$TURNS_FILE" ]; then
    TURN_COUNT=$(python3 -c "import json; print(json.load(open('$TURNS_FILE')).get('count',0))" 2>/dev/null || echo 0)
fi
TURN_MOD5=$(( TURN_COUNT % 5 ))
TURN_MOD10=$(( TURN_COUNT % 10 ))

# ═══════════════════════════════════════════════════════════════
# Tier 1: L1 工具安全规则 (每轮 — ≤3行)
# ═══════════════════════════════════════════════════════════════
case "$TOOL_NAME" in
    Edit|Write)
        L1="[L1] ✏️ Read-before-Edit | 范围冻结 | 断言需file:line | 禁改治理文件(需门禁)"
        ;;
    Bash)
        L1="[L1] 🛡️ 禁rm -rf/sudo/git push -f | 禁读写.env/私钥 | git写操作先报告 | 用Read/Edit代替cat/sed"
        ;;
    Read)
        L1="[L1] 👁️ 禁读.env/私钥/密钥 | 不扫系统目录"
        ;;
    Agent|Task)
        L1="[L1] 🤖 子agent结果需验证 | 不信任'完成'声明 | 独立任务并行派发"
        ;;
    Grep|Glob|WebSearch|WebFetch)
        L1="[L1] 🔍 搜索有证据链路 | 引用file:line来源"
        ;;
    *)
        L1="[L1] 📌 禁止编造(file:line) | 证据门禁(VERIFIED) | 哲学先行(#8)"
        ;;
esac

# ═══════════════════════════════════════════════════════════════
# Tier 2: L2 反模式+教训 (每5轮 — ~10行)
# ═══════════════════════════════════════════════════════════════
L2=""
if [ "$TURN_MOD5" -eq 0 ]; then
    L2="
[L2 反模式速查 · 锚定轮 #${TURN_COUNT}]
A假完成: 无证据说完成 ('应该没问题/基本完成/理论上/看起来正常')
B功能蔓延: 一次改太多 (跨5+文件无Step拆分)
C跳过门禁: 绕过verification (不跑test说VERIFIED)
D幻觉路径: 编造不存在文件 (引用从未创建的文件)
E规则漂移: 文档≠代码 (改了代码没改文档)
F范围冻结: 额外发现记TODO,不顺手修
G上下文污染: 冗余淹没规则
H哲学先行: 问人前先过哲学7条,能裁决则标注[哲学先行:#N→action]直接执行"
fi

# ═══════════════════════════════════════════════════════════════
# Tier 3: L3 完整规则+架构 (每10轮 — ~25行)
# ═══════════════════════════════════════════════════════════════
L3=""
if [ "$TURN_MOD10" -eq 0 ]; then
    L3="
[L3 完整规则锚定轮 #${TURN_COUNT}]

🛡️ 安全: 禁读.env/私钥 | 禁rm -rf/sudo/git push -f | git write前报告等批准 | 明文Token阻断
📝 编辑: Read-before-Edit | 范围冻结 | 治理文件需CAPTCHA | 断言必附file:line | 不写注释(除非WHY)
🎯 质量: 禁软完成语 | 完成前需VERIFIED证据 | 同问题3轮上限→BLOCKED | 哲学#8先行裁决
📐 格式: 不用emoji | 不创建README/md(除非要求) | 工具调用前不用冒号 | 不解释WHAT
🏗️ 架构: hook蛇形命名 | py下划线 | skill lx-前缀 | 版本6.2.12格式 | hook不可失败(exit0)
🔁 反自我矛盾: 机制审计门禁(pre-commit-self-review.sh) | 三源一致分歧=BLOCKED
🔄 修复: 3轮上限→换假设 | 2轮根因收敛→升高级模型 | hook禁止set -e | 禁eval

教训速查: R22(bash空变量→\${var:-default}) R24(glob污染→set -f) R29(禁.*万能matcher)
R31(拦截gh write) R33(compact后重注入) R34(逐文件验证grep≠验证) R40(Ghost永不阻断read)"
fi

# ─── 拼接输出 ───
if [ "$TURN_MOD10" -eq 0 ]; then
    # L3: 完整注入省略L2(已覆盖)
    CTX="$L1${L3}"
    TIER="L1+L3"
elif [ "$TURN_MOD5" -eq 0 ]; then
    CTX="$L1${L2}"
    TIER="L1+L2"
else
    CTX="$L1"
    TIER="L1"
fi

# ─── 通过 additionalContext 注入 ───
python3 -c "
import json, sys
ctx = sys.stdin.read()
ctx = ''.join(c for c in ctx if not (0xD800 <= ord(c) <= 0xDFFF))
print(json.dumps({'continue': True, 'hookSpecificOutput': {'hookEventName': 'PreToolUse', 'additionalContext': ctx}}))
" <<< "$CTX"

flywheel_event "pretool_rules_inject" "injected" "L2" "tool=$TOOL_NAME tier=$TIER turn=$TURN_COUNT" || true

exit 0
