#!/usr/bin/env bash
# pretool-rules-inject.sh — PreToolUse — 工具调用前注入规则提醒 (v1.0)
# 哲学 #3 (先守护): 提前告知边界，用不犯错代替犯错报错
# 哲学 #5 (以人为本): 减少拦截打断，让AI提前知道规则而非事后被阻
# 永不阻断 (exit 0) — 只注入提醒，不拦截操作
# 设计: 每5轮注入一次完整规则，其余轮次注入一行紧凑提示

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$SCRIPT_DIR/harness_config.sh"
set -f
hc_enabled "pretool_rules_inject" || { echo '{"continue": true}'; exit 0; }

INPUT=$(cat 2>/dev/null || echo "")
TOOL_NAME=""
if command -v jq &>/dev/null && [ -n "$INPUT" ]; then
    TOOL_NAME=$(echo "$INPUT" | jq -r '.tool_name // empty' 2>/dev/null)
fi
[ -z "$TOOL_NAME" ] && { echo '{"continue": true}'; exit 0; }

# ─── 轮次控制：每5轮注入完整规则，其余轮次一行紧凑提示 ───
TURNS_FILE="$PROJECT_ROOT/.omc/state/session-turns.json"
TURN_COUNT=0
if [ -f "$TURNS_FILE" ]; then
    TURN_COUNT=$(python3 -c "import json; print(json.load(open('$TURNS_FILE')).get('count',0))" 2>/dev/null || echo 0)
fi
FULL_INJECT=$(( TURN_COUNT % 5 == 0 ))

# ─── 根据工具类型选择规则 ───
case "$TOOL_NAME" in
    Edit|Write)
        RULES="🌐 编辑规则: ①Read-before-Edit(先读后改) ②范围冻结(只改当前任务文件)
③禁止修改 .claude/hooks/ .claude/harness.yaml .claude/settings.json(需CAPTCHA门禁)
④每个技术断言需 file:line 来源 ⑤不写注释(除非WHY非显而易见)"
        ;;
    Bash)
        RULES="🛡️  Bash规则: ①禁止 rm -rf / sudo / git push --force / git reset --hard
②禁止读写 .env / 私钥 / 明文Token ③git commit/push前先报告
④用Read工具代替cat/head/tail ⑤用Edit工具代替sed/awk"
        ;;
    Read)
        RULES="👁️  Read规则: ①禁止读 .env / id_rsa / secret.yml / credentials.json
②优先读项目文件,不扫描系统目录 ③Read图片/PDF用专用参数"
        ;;
    Agent|Task)
        RULES="🤖 Agent规则: ①子agent不写代码时注明'只做研究' ②独立任务并行派发
③子agent的Write/Edit结果需验证(不信任子agent的'完成'声明)"
        ;;
    *)
        RULES="📌 通用规则: ①禁止编造(file:line) ②证据门禁(VERIFIED) ③范围冻结 ④哲学先行"
        ;;
esac

# ─── 完整注入（每5轮） ───
if [ "$FULL_INJECT" = "1" ]; then
    CTX="[规则注入 #${TURN_COUNT}] 本轮为完整规则锚定轮。以下规则在本次工具调用前生效：

🛡️ 安全防线:
  · 禁止读取/写入 .env / 私钥 / 密钥文件 → 用环境变量或脱敏代理
  · 禁止 rm -rf / sudo / git push --force / git reset --hard
  · git commit/push 前必须先向用户报告，等批准

📝 编辑约束:
  · Read-before-Edit: 编辑前必须先Read该文件
  · 范围冻结: 只改当前任务涉及的文件，额外发现记TODO
  · 治理文件(.claude/hooks/ .claude/harness.yaml .claude/settings.json)需CAPTCHA门禁
  · 每个技术断言必须附带 file:line 来源

🎯 质量门禁:
  · 禁止软完成语: '应该没问题/基本完成/理论上/看起来正常'
  · 完成声明前必须提供 VERIFIED 证据(command+output)
  · 同一问题最多修3轮，超过BLOCKED升级用户
  · 问人前先过哲学7条(哲学#8)

📐 格式规范:
  · 不写注释(除非WHY非显而易见)
  · 不用emoji(除非用户要求)
  · 不创建README/markdown文档(除非用户要求)
  · 工具调用前不用冒号

${RULES}"
else
    CTX="[R#${TURN_COUNT}] ${RULES}"
fi

# ─── 输出：通过 additionalContext 注入 AI 上下文 ───
python3 -c "
import json, sys
ctx = sys.stdin.read()
ctx = ''.join(c for c in ctx if not (0xD800 <= ord(c) <= 0xDFFF))
print(json.dumps({'continue': True, 'hookSpecificOutput': {'hookEventName': 'PreToolUse', 'additionalContext': ctx}}))
" <<< "$CTX"

# 埋点（不阻断）
flywheel_event "pretool_rules_inject" "injected" "L2" "tool=$TOOL_NAME full=$FULL_INJECT" || true

exit 0
