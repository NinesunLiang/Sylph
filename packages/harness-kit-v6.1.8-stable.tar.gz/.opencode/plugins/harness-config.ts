/**
 * harness-config.ts — 读取 harness.yaml 配置（OpenCode plugin 用）
 * 对应 Claude Code 版本的 harness_config.sh
 */

import { readFileSync, existsSync, statSync } from "fs";
import { resolve, join } from "path";

export interface HarnessConfig {
  // hooks 开关
  hooks_enabled: Record<string, boolean>;
  // completion_gate
  completion_gate: { min_evidence_chars: number; required_keyword: string };
  // permission_gate 正则
  permission_gate: {
    git_push_regex: string;
    git_push_force_regex: string;
    git_commit_regex: string;
    destructive_regex: string;
    sudo_regex: string;
  };
  // rule_anchor
  rule_anchor: { turn_threshold: number; interval: number };
  // turn_counter
  turn_counter: { todo_refresh_interval: number };
  // project
  project: { language: string; source_extensions: string };
  // knowledge 注入文件
  knowledge: { inject_files: string[] };
  // correction_detector
  correction_detector: { signals: string };
  // raw: 所有扁平化 key=value
  raw: Record<string, string>;
}

const DEFAULT: HarnessConfig = {
  hooks_enabled: {
    completion_gate: true,
    permission_gate: true,
    privacy_gate: true,
    pretool_edit_scope: true,
    edit_guard: true,
    posttool_bash_audit: true,
    posttool_edit_quality: true,
    posttool_write_cite: true,
    posttool_read_cite: false,
    pretool_rule_anchor: true,
    subagent_guard: true,
    turn_counter: true,
    inject_project_knowledge: true,
    auto_snapshot: true,
    error_dna: true,
    build_validator: true,
    read_tracker: true,
    user_correction_detector: true,
  },
  completion_gate: {
    min_evidence_chars: 20,
    required_keyword: "VERIFIED",
  },
  permission_gate: {
    git_push_regex: String.raw`git\s+push\b`,
    git_push_force_regex: String.raw`git\s+push.*--?force`,
    git_commit_regex: String.raw`git\s+commit`,
    destructive_regex: String.raw`\brm\s+-rf\b|\bdrop\s+(table|database)\b|\btruncate\b|\bdelete\s+from\b`,
    sudo_regex: String.raw`^\s*sudo\b`,
  },
  rule_anchor: {
    turn_threshold: 15,
    interval: 5,
  },
  turn_counter: {
    todo_refresh_interval: 10,
  },
  project: {
    language: "generic",
    source_extensions: "*",
  },
  knowledge: {
    inject_files: ["index.md:full", "kernel.md:full"],
  },
  correction_detector: {
    signals: "不对 错了 你搞错了 应该是 重新来",
  },
  raw: {},
};

/** 简单 YAML 扁平化解析（对应 harness_config.sh 的 python3 逻辑） */

function parseYamlFlat(path: string): Record<string, string> {
  const result: Record<string, string> = {};
  const text = readFileSync(path, "utf-8");
  let currentSection = "";
  let listKey = "";
  const listItems: string[] = [];

  for (const rawLine of text.split("\n")) {
    const line = rawLine.trimEnd();
    const stripped = line.trim();

    // 空行或注释
    if (!stripped || stripped.startsWith("#")) {
      if (listKey && listItems.length) {
        result[listKey] = listItems.join(" ");
        listKey = "";
        listItems.length = 0;
      }
      continue;
    }

    const indent = line.length - line.trimStart().length;

    // 列表项
    if (stripped.startsWith("- ")) {
      if (listKey) {
        listItems.push(stripped.slice(2).trim().replace(/^['"]|['"]$/g, ""));
      }
      continue;
    }

    // 结束列表
    if (listKey && listItems.length) {
      result[listKey] = listItems.join(" ");
      listKey = "";
      listItems.length = 0;
    }

    if (stripped.includes(":")) {
      const colonIdx = stripped.indexOf(":");
      const key = stripped.slice(0, colonIdx).trim();
      let value = stripped.slice(colonIdx + 1).trim();
      // 去引号
      if (
        value &&
        ((value[0] === '"' && value.endsWith('"')) ||
          (value[0] === "'" && value.endsWith("'")))
      ) {
        value = value.slice(1, -1);
      }

      if (indent === 0) {
        if (value) result[key] = value;
        else currentSection = key;
      } else if (currentSection) {
        const flatKey = `${currentSection}.${key}`;
        if (value) result[flatKey] = value;
        else {
          listKey = flatKey;
          listItems.length = 0;
        }
      }
    }
  }

  if (listKey && listItems.length) result[listKey] = listItems.join(" ");
  return result;
}

let _cache: HarnessConfig | null = null;
let _cacheTime = 0;
let _yamlMtime = 0;

export function loadHarnessConfig(projectRoot?: string): HarnessConfig {
  const root = projectRoot ?? process.cwd();
  const yamlPath = join(root, ".claude", "harness.yaml");

  if (!existsSync(yamlPath)) return DEFAULT;

  // 缓存检查
  const mtime = statSync(yamlPath).mtimeMs;
  if (_cache && mtime === _yamlMtime) return _cache;

  try {
    const raw = parseYamlFlat(yamlPath);
    _yamlMtime = mtime;

    const getBool = (key: string, def: boolean) => {
      const v = raw[key];
      if (v === undefined) return def;
      return v.trim() === "true";
    };
    const getStr = (key: string, def: string) => raw[key]?.trim() ?? def;
    const getInt = (key: string, def: number) => {
      const v = parseInt(raw[key] ?? "", 10);
      return isNaN(v) ? def : v;
    };

    _cache = {
      hooks_enabled: Object.fromEntries(
        Object.entries(DEFAULT.hooks_enabled).map(([k, def]) => [
          k,
          getBool(`hooks_enabled.${k}`, def),
        ])
      ),
      completion_gate: {
        min_evidence_chars: getInt("completion_gate.min_evidence_chars", 20),
        required_keyword: getStr("completion_gate.required_keyword", "VERIFIED"),
      },
      permission_gate: {
        git_push_regex: getStr("permission_gate.git_push_regex", DEFAULT.permission_gate.git_push_regex),
        git_push_force_regex: getStr("permission_gate.git_push_force_regex", DEFAULT.permission_gate.git_push_force_regex),
        git_commit_regex: getStr("permission_gate.git_commit_regex", DEFAULT.permission_gate.git_commit_regex),
        destructive_regex: getStr("permission_gate.destructive_regex", DEFAULT.permission_gate.destructive_regex),
        sudo_regex: getStr("permission_gate.sudo_regex", DEFAULT.permission_gate.sudo_regex),
      },
      rule_anchor: {
        turn_threshold: getInt("rule_anchor.turn_threshold", 15),
        interval: getInt("rule_anchor.interval", 5),
      },
      turn_counter: {
        todo_refresh_interval: getInt("turn_counter.todo_refresh_interval", 10),
      },
      project: {
        language: getStr("project.language", "generic"),
        source_extensions: getStr("project.source_extensions", "*"),
      },
      knowledge: {
        inject_files: getStr("knowledge.inject_files", "index.md:full kernel.md:full").split(" "),
      },
      correction_detector: {
        signals: getStr("correction_detector.signals", "不对 错了 你搞错了 应该是 重新来"),
      },
      raw,
    };
    return _cache;
  } catch {
    return DEFAULT;
  }
}
