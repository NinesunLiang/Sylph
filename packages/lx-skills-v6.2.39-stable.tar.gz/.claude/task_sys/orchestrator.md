# Orchestrator - 任务调度器

> >
> 状态机 + Gate 检查点 + 失败回退
> 版本：v5.1.0

---

## 第一层：身份与边界层
**核心契约**：结构化任务输入

```yaml
e
: {$1}role: {$2}target: {$3}pass_criteria: {$4}executor_mode: {$5} # stepwise | racepriority: {$6} # p0 | p1 | p2
yamltask_name: {$1}role: {$2}target: {$3}pass_criteria: {$4}executor_mode: {$5} # stepwise | racepriority: {$6} # p0 | p1 | p2
```

---

## 第二层：执行引擎 - 混合状态机

### 状态机（v5.1.0 简化版）

```need_clarificati
o
n → ready → planning → executing → done ↑ ↑ ↑ ↑ └──── blocked ─────┘ └─ fallback ┘ ↓ need_clarification (偏差时)
need_clarification → ready → planning → executing → done ↑ ↑ ↑ ↑ └──── blocked ─────┘ └─ fallback ┘ ↓ need_clarification (偏差时)
```

### 状态定义
| 状态 | 含义 | 触发条件 | 下一状态|
|------|------|---------|---------|
|`need_clarification` | 需要用户澄清 | criteria 缺失 / target 模糊 | `ready`（用户确认后）|
|`ready` | 任务已就绪，可进入规划 | 所有必填字段已确认 | `planning`|
|`planning` | 正在制定计划 | 非琐碎任务（≥3步或含架构决策） | `executing`（Plan Gate 通过后）|
|`executing` | 正在实施 | Plan Gate 通过，方案已锁定 | `done` / `blocked`|
|`blocked` | 受阻，等待外部输入 | 3轮修复失败 / 依赖缺失 | `executing`（用户提供新约束后）|
|`done` | 完成且验收通过 | 所有 AC 通过，验收报告已生成 | 终态 |

### 三步工作流

#### 1. 调研阶段- 收集信息 → 评估不确定性 → 探索方案- **Gate 检查点**（Research Gate）： - [ ] 所有涉及文件已 Read 并标注 file:line - [ ] 外部依赖/接口契约已查明 - [ ] 不存在未解答的技术问题 - [ ] 与现有代码的集成点已定位

#### 2. 规划阶段- 分解任务 → 定义步骤 → 分析依赖 → 分配资源- **Gate 检查点**（Plan Gate）： - [ ] 每个 Step 有明确验收标准 - [ ] Step 间依赖关系已标注 - [ ] 预估影响文件已列出 - [ ] 用户已确认方案

#### 3. 执行阶段- 实施 → 调试 → 验证 → 文档化 → 同步

### 质量控制
| 阶段 | 类型 | 内容|
|------|------|------|
|前置 | 检查点 | Research Gate + Plan Gate|
|过程 | 监控 | 每步证据记录 + 熔断机制|
|后置 | 验证 | A/B 终端分离验收 |

### 补充设计
1. **先规划**：将计划写入 `.omc/state/{date}/{task_name}/output/plan.md`，使用可勾选清单2. **验证计划**：实现前先 check-in3. **跟踪进度**：每完成一项即标记4. **解释变更**：每步提供高层总结5. **记录结果**：在 plan.md 末尾添加 checklist 部分6. **捕捉教训**：纠正后更新 `.claude/next-learn`

---

## 第三层：记忆系统 - 三层结构

### 短期记忆：渐进性披露- 大纲 → 步骤 → 执行- 当前步骤只访问必要资源- 严格边界，不越界

### 中期记忆：Markdown 文档化- 每个步骤：[方案文档] + [验收文档]- 每个章节：汇总更新任务状态

### 长期记忆：飞轮迭代- 收集错误模式- 识别成功模式- 持续优化迭代

---

## 第四层：验收系统 - A/B 终端分离

### A 终端（生成验收方案）- **输入**：任务目标- **输出**：通过/不通过的具体现象标准- **埋点**：可观测的检查点

### B 终端（执行验收）- **输入**：实际产出- **输出**：验收报告（命中哪些现象）

### 验证机制A 终端对比验收报告与标准 → 判定通过/不通过

---

## 第五层：韧性机制 - 三层保障

### 1. 优雅降级- 核心功能优先保障- 非核心可降级或放弃

### 2. 全链路溯源- 输入 → 处理 → 输出- 每个决策可追溯

### 3. 自动恢复- 重试机制（有限次数，最多 3 轮）- 错误收集与分析- 自我修复尝试

---

## 第六层：学习进化 - 飞轮系统
**循环**：执行 → 收集错误 → 分析优化 → 再次执行
**目标**：避免重复错误，固化成功模式

---

## 设计哲学
| # | 原则 | 含义|
|---|------|------|
|1 | **契约优先** | 明确的接口定义|
|2 | **逐步展开** | 渐进性信息披露|
|3 | **分离关注** | 生成与执行分离|
|4 | **闭环学习** | 从错误中持续进化|
|5 | **优雅降级** | 永远提供有价值输出 |

---

## 失败回退策略
| 失败类型 | 回退动作 | 升级条件|
|---------|---------|---------|
|Research Gate 未通过 | 标记 BLOCKED，列出缺失信息 | 用户提供新线索 → Half-Open 试探|
|Plan Gate 未通过 | 返回 planning 重新规划 | 用户确认替代方案|
|Spec Gate 未通过 | 返回 spec_review 修改技术方案 | 用户确认修改后的方案|
|执行中 1 轮失败 | 记录根因 → 尝试不同策略 | 仍在 executing 状态|
|执行中 2 轮失败 | **触发 Fallback Exploration** → 产出方案对比 + 降级路径 | 用户确认新方案 → 轮次重置|
|执行中 3 轮失败 + Fallback 耗尽 | 标记 BLOCKED，写入 fallback_analysis.md | 请求用户决策|
|验收未通过 | 回到 executing 修复（最多 3 轮） | 超过 3 轮 → BLOCKED|
|上下文 >40% | 触发总结并重置（见 context_guard.md） | 自动 |

### Fallback 降级流程

```执行失
败
（≥2轮） → 触发 Fallback Exploration ├─ explore agent: 搜索代码库既有解法 ├─ librarian agent: 搜索外部最佳实践 └─ 产出：方案对比表 + 降级路径（A→B→C） → 用户确认方案 → 轮次计数重置 → 回到 executing
执行失败（≥2轮） → 触发 Fallback Exploration ├─ explore agent: 搜索代码库既有解法 ├─ librarian agent: 搜索外部最佳实践 └─ 产出：方案对比表 + 降级路径（A→B→C） → 用户确认方案 → 轮次计数重置 → 回到 executing
```
