#!/usr/bin/env bash
# pretool-rules-inject.sh — PreToolUse — 3级脱水分层注入 (v3.0)
# 永不阻断 (exit 0)
#
# L1 (每轮):  哲学7条 + 8条铁律 — AI最高指导原则, 零感知负担
# L2 (每5轮): 工作流原则 + 决策链 — 提升AI处理任务效率
# L3 (每10轮): AGENTS.md渐进式披露 + TODO列表 — 强化方向感

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$SCRIPT_DIR/harness_config.sh"
set -f
hc_enabled "pretool_rules_inject" || { echo '{"continue": true}'; exit 0; }

INPUT=$(cat 2>/dev/null || echo "")
TOOL_NAME=""
if command -v jq &>/dev/null && [ -n "$INPUT" ]; then
    TOOL_NAME=$(echo "$INPUT" | jq -r '.tool_name // empty' 2>/dev/null)
fi
[ -z "$TOOL_NAME" ] && { echo '{"continue": true}'; exit 0; }

# ─── 轮次 ───
TURNS_FILE="$PROJECT_ROOT/.omc/state/session-turns.json"
TURN_COUNT=0
if [ -f "$TURNS_FILE" ]; then
    TURN_COUNT=$(python3 -c "import json; print(json.load(open('$TURNS_FILE')).get('count',0))" 2>/dev/null || echo 0)
fi

# ═══════════════════════════════════════════════════════════
# L1: 哲学 + 铁律 (每轮 — AI最高指导原则)
# ═══════════════════════════════════════════════════════════

case "$TOOL_NAME" in
    Edit|Write)
        L1_TOOL="✏️ Read-before-Edit | 范围冻结 | 断言需file:line | 改前先getDiagnostics检查LSP错误"
        ;;
    Bash)
        L1_TOOL="🛡️ 禁rm -rf/sudo/git push -f | 禁读写.env/私钥 | 用Read/Edit代替cat/sed | 用getDiagnostics检查错误"
        ;;
    Read)
        L1_TOOL="👁️ 禁读.env/私钥/密钥 | 用getDiagnostics检查代码质量"
        ;;
    Grep|Glob|WebSearch|WebFetch)
        L1_TOOL="🔍 搜索前先getDiagnostics了解当前错误 | 引用file:line来源"
        ;;
    Agent|Task)
        L1_TOOL="🤖 子agent结果需验证 | 派发前先getDiagnostics传递给子agent | 独立任务并行"
        ;;
    *)
        L1_TOOL="📌 禁止编造(file:line) | 证据门禁(VERIFIED) | 善用getDiagnostics主动发现错误"
        ;;
esac

L1="[L1·铁律] ${L1_TOOL}
[L1·哲学] #4(验证)>#6(0信任)>#3(守护)>#7(文档)>#5(人)>#2(增益)>#1(less)
[L1·铁律] ①禁编造(file:line) ②用户裁定 ③证据门禁(VERIFIED) ④Git门禁(报告→批准→提交) ⑤范围冻结 ⑥隐私防线 ⑦断言真实 ⑧哲学先行"

# ═══════════════════════════════════════════════════════════
# L2: 工作流原则 + 决策链 (每5轮)
# ═══════════════════════════════════════════════════════════
L2=""
if [ $(( TURN_COUNT % 5 )) -eq 0 ]; then
    L2="
[L2·工作流] 锚定轮 #${TURN_COUNT}
难度分级: L1简单→直接执行 | L2中等→Step清单→逐Step验证 | L3复杂→7步流水线(列方案→细分→实现→Debug→强证据→Oracle→下一步) | L4关键→三重门+Oracle终审
Oracle终审: L2+变更→AI自验→Oracle独立审核(Opus)→ACCEPT才能说'已完成' | REVISE→修复→重审 | REJECT→停止,报告驳回理由
修复上限: 同一问题≤3轮 | 第3轮仍失败→BLOCKED升级用户 | 每轮换假设,禁盲目重试
决策链: 过程性问题→哲学#4(执行) | 抉择性问题→哲学#2(少改动) | 不可逆/安全/偏好/法律→必须问人
会话恢复: Read .omc/state/todo-queue.md + session-handoff.md | 有[·]进行中任务→报告用户'是否继续?'
自我改进: 用户每次纠正→更新.claude/claude-next.md | 新经验→写作R编号教训(原则:发现bug→写R教训→补hook/smoke test→永不重犯)"
fi

# ═══════════════════════════════════════════════════════════
# L3: 渐进式披露 + TODO (每10轮)
# ═══════════════════════════════════════════════════════════
L3=""
if [ $(( TURN_COUNT % 10 )) -eq 0 ]; then
    # ─── TODO 列表 ───
    TODO_CTX=""
    TODO_QUEUE="$PROJECT_ROOT/.omc/state/todo-queue.md"
    if [ -f "$TODO_QUEUE" ]; then
        TODO_CTX=$(head -20 "$TODO_QUEUE" 2>/dev/null | grep -E '^\[.\]\|###\|#' | head -8)
    fi
    [ -z "$TODO_CTX" ] && TODO_CTX="(无待办)"

    L3="
[L3·渐披+方向] 锚定轮 #${TURN_COUNT}

📍 方向感: 完成当前Step→报告进度→指明下一步 | 选项附带后果+推荐 | 末尾放自定义出口
📖 渐进式披露: Read展开→哲学→AGENTS.md三源理论→.claude/reference/three-source-consistency.md Meta-Oracle→.claude/reference/meta-oracle.md 反模式→.claude/anti-patterns.md 教训→.claude/claude-next.md 架构→.claude/kernel.md
⚖️ 权威: Boss指令>项目宪法>PRD>Skill>设计文档>代码
🔬 三源: SourceI(AI规则)+SourceII(hook注册)+SourceIII(运行时验证)→分歧=BLOCKED
🧠 核心上下文: kernel.md(架构铁律/命名/错误处理/测试) + anti-patterns.md(16条反模式) + claude-next.md(教训R22-R41)
🔁 反自我矛盾: pre-commit-self-review.sh | 覆盖真实度验证后的hook合规
📐 格式: 不用emoji | 不创建README/md(除非要求) | 不解释代码做什么 | 不写注释(除非WHY)
📋 断点续传: 新会话检查session-handoff.md | 审计最后2条todo完成状态 | 读到[·]标记→报告'上次在进行X,要继续吗?'

📋 TODO:
${TODO_CTX}"
fi

# ─── 拼接 ───
if [ $(( TURN_COUNT % 10 )) -eq 0 ]; then
    CTX="${L1}${L3}"
    TIER="L1+L3"
elif [ $(( TURN_COUNT % 5 )) -eq 0 ]; then
    CTX="${L1}${L2}"
    TIER="L1+L2"
else
    CTX="$L1"
    TIER="L1"
fi

# ─── 注入 ───
python3 -c "
import json, sys
ctx = sys.stdin.read()
ctx = ''.join(c for c in ctx if not (0xD800 <= ord(c) <= 0xDFFF))
print(json.dumps({'continue': True, 'hookSpecificOutput': {'hookEventName': 'PreToolUse', 'additionalContext': ctx}}))
" <<< "$CTX"

flywheel_event "pretool_rules_inject" "injected" "L2" "tool=$TOOL_NAME tier=$TIER turn=$TURN_COUNT" || true

exit 0
